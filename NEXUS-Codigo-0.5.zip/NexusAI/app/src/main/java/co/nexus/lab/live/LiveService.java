package co.nexus.lab.live;

import android.accessibilityservice.*;
import android.app.KeyguardManager;
import android.content.*;
import android.graphics.*;
import android.hardware.HardwareBuffer;
import android.os.*;
import android.util.DisplayMetrics;
import android.view.*;
import android.view.accessibility.*;
import android.widget.*;
import android.util.AtomicFile;
import java.io.*;

/** User-started visual tracking experiment. All callbacks are serialized on the main looper. */
public final class LiveService extends AccessibilityService {
    static LiveService connected;
    private final Handler loop=new Handler(Looper.getMainLooper());
    private final Tracker tracker=new Tracker();
    private final int[] rgb=new int[Tracker.W*Tracker.H];
    private final float[] camera=new float[2],stick=new float[2],fire=new float[2],mark=new float[2];
    private String game;
    private int mode,phase,unknown,repeat;
    private MatchBook book;private MatchBook.Example previous;
    private byte[] pending;private boolean reading;
    private Button phaseKey,runKey;
    private AtomicFile profile(String pkg){return new AtomicFile(new File(getFilesDir(),"partida-"+pkg+".bin"));}
    boolean prepare(String pkg,boolean move,boolean tap,int requested){
        MatchBook loaded=new MatchBook();
        if(requested!=0){
            try(DataInputStream in=new DataInputStream(profile(pkg).openRead())){loaded=MatchBook.read(in);}
            catch(FileNotFoundException absent){}catch(IOException damaged){return false;}
            if(requested==2&&!loaded.ready())return false;
        }
        arm(pkg,move,tap);mode=requested;book=loaded;phase=unknown=repeat=0;previous=null;reading=false;return game!=null;
    }
    private boolean persist(){
        AtomicFile f=profile(game);FileOutputStream stream=null;
        try{stream=f.startWrite();DataOutputStream out=new DataOutputStream(stream);book.write(out);out.flush();f.finishWrite(stream);return true;}
        catch(IOException e){if(stream!=null)f.failWrite(stream);return false;}
    }
    private boolean move,tap,entered,tracking,chosen;
    private int generation,width,height,step,gestures,adjustments;
    private double gx,gy,prevX,prevY,cmdX,cmdY;
    private long deadline,nextTap;
    private WindowManager wm;
    private LinearLayout bar;
    private FrameLayout picker;
    private Button calibrate;
    private TextView info;
    private String summary="";
    @Override protected void onServiceConnected(){connected=this;wm=getSystemService(WindowManager.class);}
    @Override public void onInterrupt(){end("Sesión interrumpida.");}
    @Override public void onDestroy(){end("Servicio desconectado.");if(connected==this)connected=null;super.onDestroy();}
    private boolean foreground(){
        if(game==null||getSystemService(KeyguardManager.class).isKeyguardLocked()||!getSystemService(PowerManager.class).isInteractive())return false;
        // An accessibility overlay can be the most recently touched window. Identify the
        // underlying app, and suspend while a focused system dialog or keyboard covers it.
        for(AccessibilityWindowInfo win:getWindows()){
            int type=win.getType();
            if(type==AccessibilityWindowInfo.TYPE_ACCESSIBILITY_OVERLAY)continue;
            if(type==AccessibilityWindowInfo.TYPE_INPUT_METHOD || (type==AccessibilityWindowInfo.TYPE_SYSTEM&&win.isFocused()))return false;
            if(type!=AccessibilityWindowInfo.TYPE_APPLICATION)continue;
            AccessibilityNodeInfo root=win.getRoot();
            if(root==null)return false;
            try{return root.getPackageName()!=null && game.contentEquals(root.getPackageName());}
            finally{root.recycle();}
        }
        return false;
    }
    void arm(String pkg,boolean movement,boolean action){
        end("");if(Build.VERSION.SDK_INT<30||!("com.dts.freefireth".equals(pkg)||"com.dts.freefiremax".equals(pkg)))return;
        game=pkg;move=movement;tap=action;deadline=SystemClock.elapsedRealtime()+60000;
        gx=getSharedPreferences("live",0).getFloat(pkg+".gx",1);gy=getSharedPreferences("live",0).getFloat(pkg+".gy",1);
        gestures=adjustments=0;entered=false;nextTap=0;loop.post(guard);
    }
    private final Runnable guard=new Runnable(){public void run(){
        if(game==null)return;
        if(SystemClock.elapsedRealtime()>deadline){end("Tiempo de sesión agotado.");return;}
        if(!foreground()){if(entered){end("El juego salió de primer plano.");return;}}
        else if(!entered){entered=true;deadline=SystemClock.elapsedRealtime()+(mode==0?600000:2700000);try{showBar();}catch(RuntimeException e){end("Panel no disponible.");return;}}
        else if(tracking && !sameDisplay()){end("La pantalla cambió de orientación.");return;}
        loop.postDelayed(this,320);
    }};
    @Override public void onAccessibilityEvent(AccessibilityEvent e){
        if(entered && game!=null && e.getEventType()==AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED && !foreground())end("Se cerró la sesión al cambiar de ventana.");
    }
    private DisplayMetrics metrics(){DisplayMetrics d=new DisplayMetrics();wm.getDefaultDisplay().getRealMetrics(d);return d;}
    private boolean sameDisplay(){DisplayMetrics d=metrics();return width==d.widthPixels&&height==d.heightPixels;}
    private void remove(View v){if(v!=null&&wm!=null)try{wm.removeViewImmediate(v);}catch(IllegalArgumentException ignored){}}
    void end(String reason){
        generation++;loop.removeCallbacksAndMessages(null);boolean was=game!=null;
        if(was){summary=reason+" Gestos: "+gestures+" · ajustes: "+adjustments;getSharedPreferences("live",0).edit().putString("last",summary)
            .putFloat(game+".gx",(float)gx).putFloat(game+".gy",(float)gy).apply();}
        game=null;pending=null;reading=false;tracking=false;entered=false;chosen=false;remove(picker);picker=null;remove(bar);bar=null;
    }
    private WindowManager.LayoutParams params(int w,int h){
        WindowManager.LayoutParams p=new WindowManager.LayoutParams(w,h,WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE|WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,PixelFormat.TRANSLUCENT);
        p.gravity=Gravity.TOP|Gravity.LEFT;return p;
    }
    private Button button(String s){Button b=new Button(this);b.setText(s);b.setTextSize(12);b.setAllCaps(false);return b;}
    private void showBar(){
        bar=new LinearLayout(this);bar.setGravity(Gravity.CENTER_VERTICAL);bar.setBackgroundColor(0xee101c33);
        info=new TextView(this);info.setTextColor(0xff51f5df);info.setText(" NEXUS ");info.setTextSize(12);bar.addView(info);
        calibrate=button("Calibrar");calibrate.setOnClickListener(v->beginPick());bar.addView(calibrate);
        if(mode!=0){
            calibrate.setVisibility(View.GONE);
            if(mode==1){phaseKey=button(MatchBook.PHASES[phase]);phaseKey.setOnClickListener(v->{if(!reading&&!tracking){phase=(phase+1)%4;phaseKey.setText(MatchBook.PHASES[phase]);}});bar.addView(phaseKey);}
            runKey=button(mode==1?"Mostrar gesto":"Iniciar");runKey.setOnClickListener(v->beginMatch());bar.addView(runKey);
        }
        Button stop=button("Detener");stop.setOnClickListener(v->end("Detenida por el usuario."));bar.addView(stop);
        wm.addView(bar,params(-2,-2));
    }
    private void beginMatch(){
        if(!foreground())return;DisplayMetrics d=metrics();width=d.widthPixels;height=d.heightPixels;
        if(width<=height){info.setText(" Gira el teléfono ");return;}
        if(tracking||reading)return;
        generation++;unknown=repeat=0;previous=null;tracking=true;runKey.setEnabled(false);
        info.setText(" Leyendo ");schedule(520);
    }
    private void matchIdle(String message){
        generation++;reading=false;pending=null;tracking=false;remove(picker);picker=null;bar.setVisibility(View.VISIBLE);runKey.setEnabled(true);info.setText(" "+message+" ");
    }
    private void example(byte[] f,float x,float y,float u,float v,int duration){
        try{book.add(phase,f,x,y,u,v,duration);}catch(RuntimeException ex){matchIdle("Perfil lleno o gesto inválido");return;}
        if(!persist()){book.examples.remove(book.examples.size()-1);matchIdle("Error al guardar");return;}
        matchIdle("Ejemplos: "+book.examples.size());
    }
    private void teach(byte[] features){
        if(phase==3){example(features,0,0,0,0,60);return;}
        if(book.examples.size()>=MatchBook.MAX){matchIdle("Perfil lleno");return;}
        pending=features;reading=true;bar.setVisibility(View.GONE);picker=new FrameLayout(this);
        Button cancel=button("Cancelar ejemplo");cancel.setOnClickListener(v->matchIdle("Cancelado"));picker.addView(cancel,new FrameLayout.LayoutParams(-2,-2,Gravity.TOP|Gravity.RIGHT));
        picker.setOnTouchListener(new View.OnTouchListener(){
            float x,y;long down;
            public boolean onTouch(View view,MotionEvent e){
                if(!foreground()||!sameDisplay()){end("Ventana cambiada");return true;}
                if(e.getAction()==MotionEvent.ACTION_DOWN){x=e.getRawX()/width;y=e.getRawY()/height;down=e.getEventTime();}
                if(e.getAction()==MotionEvent.ACTION_UP){
                    float u=e.getRawX()/width,v=e.getRawY()/height;int ms=(int)clamp(e.getEventTime()-down,60,2000);byte[] features=pending;
                    remove(picker);picker=null;bar.setVisibility(View.VISIBLE);info.setText(" Aplicando ");
                    int id=generation;
                    loop.postDelayed(()->{if(valid(id))perform(id,x,y,u,v,ms,()->example(features,x,y,u,v,ms));},180);
                }
                if(e.getAction()==MotionEvent.ACTION_CANCEL&&picker!=null)matchIdle("Cancelado");
                return true;
            }
        });
        wm.addView(picker,params(-1,-1));
    }
    private void perform(int id,float x,float y,float u,float v,int ms,Runnable completed){
        if(!valid(id))return;
        GestureDescription.Builder b=new GestureDescription.Builder();stroke(b,x,y,u,v,ms);
        boolean ok=dispatchGesture(b.build(),new GestureResultCallback(){
            public void onCompleted(GestureDescription g){if(valid(id)){gestures++;completed.run();}}
            public void onCancelled(GestureDescription g){if(valid(id))matchIdle("Gesto cancelado");}
        },loop);
        if(!ok)matchIdle("Gesto rechazado");
    }
    private void match(int id){
        byte[] f=MatchBook.describe(rgb,Tracker.W,Tracker.H);
        if(mode==1){teach(f);return;}
        MatchBook.Example e=book.choose(phase,f);
        if(e==null){info.setText(" Buscando fase ");if(++unknown>90){matchIdle("Escena desconocida");return;}schedule(1000);return;}
        phase=e.phase;unknown=0;
        if(phase==3){end("Pantalla de resultados reconocida.");return;}
        if(e==previous){if(++repeat>12){matchIdle("Escena repetida");return;}}else{repeat=0;previous=e;}
        info.setText(" "+MatchBook.PHASES[phase]+" ");
        perform(id,e.x,e.y,e.u,e.v,e.millis,()->schedule(850));
    }
    private String prompt(){
        if(step==0)return "Toca una zona libre donde arrastrar la cámara";
        if(step==1)return "Toca el centro del joystick";
        if(step==2)return "Toca el botón de acción que quieres pulsar";
        return "Toca un detalle contrastado de la diana";
    }
    private void beginPick(){
        if(!foreground()){end("El juego no está activo.");return;}
        DisplayMetrics d=metrics();width=d.widthPixels;height=d.heightPixels;
        if(width<=height){info.setText(" Gira a horizontal ");return;}
        generation++;tracking=false;chosen=false;cmdX=cmdY=0;step=0;
        bar.setVisibility(View.GONE);picker=new FrameLayout(this);LinearLayout guide=new LinearLayout(this);
        guide.setBackgroundColor(0xee101c33);TextView label=new TextView(this);label.setTextColor(-1);label.setText(prompt());guide.addView(label);
        Button stop=button("Detener");stop.setOnClickListener(v->end("Detenida durante calibración."));guide.addView(stop);
        picker.addView(guide,new FrameLayout.LayoutParams(-2,-2,Gravity.TOP|Gravity.CENTER_HORIZONTAL));
        picker.setOnTouchListener((v,e)->{
            if(e.getAction()!=MotionEvent.ACTION_UP)return true;
            if(!foreground()||!sameDisplay()){end("Cambió la ventana durante la calibración.");return true;}
            float[] point=step==0?camera:step==1?stick:step==2?fire:mark;
            point[0]=e.getRawX()/width;point[1]=e.getRawY()/height;
            if(point[0]<.02||point[0]>.98||point[1]<.03||point[1]>.97){label.setText("Elige un punto dentro del campo");return true;}
            if(step<3){step++;if(step==1&&!move)step++;if(step==2&&!tap)step++;label.setText(prompt());return true;}
            remove(picker);picker=null;bar.setVisibility(View.VISIBLE);chosen=false;tracking=true;calibrate.setEnabled(false);
            info.setText(" Lectura… ");schedule(450);return true;
        });
        wm.addView(picker,params(-1,-1));
    }
    private void pauseTrack(String why){
        if(mode!=0){matchIdle(why);return;}
        generation++;tracking=false;cmdX=cmdY=0;calibrate.setEnabled(true);info.setText(" "+why+" ");
    }
    private boolean valid(int id){
        if(game==null||generation!=id||!tracking)return false;
        if(!foreground()||!sameDisplay()||SystemClock.elapsedRealtime()>deadline){end("Sesión finalizada.");return false;}
        return true;
    }
    private void schedule(long ms){final int id=generation;loop.postDelayed(()->{if(valid(id))capture(id);},ms);}
    private void capture(int id){
        try{takeScreenshot(Display.DEFAULT_DISPLAY,getMainExecutor(),new TakeScreenshotCallback(){
            public void onSuccess(ScreenshotResult r){
                HardwareBuffer buffer=r.getHardwareBuffer();Bitmap hw=null,small=null,soft=null;
                try{
                    if(!valid(id))return;
                    hw=Bitmap.wrapHardwareBuffer(buffer,r.getColorSpace());
                    if(hw==null||hw.getWidth()!=width||hw.getHeight()!=height){pauseTrack("Imagen incompatible");return;}
                    small=Bitmap.createScaledBitmap(hw,Tracker.W,Tracker.H,true);soft=small.copy(Bitmap.Config.ARGB_8888,false);
                    soft.getPixels(rgb,0,Tracker.W,0,0,Tracker.W,Tracker.H);
                }catch(RuntimeException|OutOfMemoryError ex){if(valid(id))pauseTrack("Imagen no disponible");return;}
                finally{if(soft!=null)soft.recycle();if(small!=null&&small!=hw)small.recycle();if(hw!=null)hw.recycle();buffer.close();}
                if(valid(id)){if(mode==0)observe(id);else match(id);}
            }
            public void onFailure(int error){if(valid(id))pauseTrack("Captura bloqueada ("+error+")");}
        });}catch(RuntimeException e){if(valid(id))pauseTrack("Sin permiso de captura");}
    }
    private void observe(int id){
        if(!chosen){
            chosen=tracker.select(rgb,(int)(mark[0]*Tracker.W),(int)(mark[1]*Tracker.H));
            if(!chosen){pauseTrack("Detalle insuficiente");return;}
        }
        int[] p=tracker.locate(rgb);
        if(p==null){pauseTrack("Referencia perdida");return;}
        double x=p[0]/(double)Tracker.W-.5,y=p[1]/(double)Tracker.H-.5;
        double nx=Tracker.adapt(gx,prevX,x,cmdX),ny=Tracker.adapt(gy,prevY,y,cmdY);
        if(nx!=gx||ny!=gy){gx=nx;gy=ny;adjustments++;}
        prevX=x;prevY=y;boolean centered=Math.abs(x)<.035&&Math.abs(y)<.045;
        cmdX=centered?0:clamp(x*.45/gx,-.07,.07);cmdY=centered?0:clamp(y*.45/gy,-.09,.09);
        GestureDescription.Builder b=new GestureDescription.Builder();int strokes=0;
        if(!centered){double ex=clamp(camera[0]+cmdX,.02,.98),ey=clamp(camera[1]+cmdY,.04,.96);
            cmdX=ex-camera[0];cmdY=ey-camera[1];stroke(b,camera[0],camera[1],ex,ey,140);strokes++;}
        if(move&&Math.abs(x)<.10){stroke(b,stick[0],stick[1],stick[0],Math.max(.04,stick[1]-.08),230);strokes++;}
        long now=SystemClock.elapsedRealtime();
        if(tap&&centered&&now>=nextTap){stroke(b,fire[0],fire[1],fire[0],fire[1],60);nextTap=now+1000;strokes++;}
        info.setText(" NEXUS · "+gestures+" ");
        if(strokes==0){schedule(520);return;}
        if(!valid(id))return;
        boolean sent=dispatchGesture(b.build(),new GestureResultCallback(){
            public void onCompleted(GestureDescription g){if(valid(id)){gestures++;schedule(520);}}
            public void onCancelled(GestureDescription g){if(valid(id))pauseTrack("Gesto cancelado");}
        },loop);
        if(!sent)pauseTrack("Gesto rechazado");
    }
    private static double clamp(double x,double a,double b){return Math.max(a,Math.min(b,x));}
    private void stroke(GestureDescription.Builder b,double x,double y,double ex,double ey,long time){
        Path path=new Path();path.moveTo((float)(width*x),(float)(height*y));
        if(x!=ex||y!=ey)path.lineTo((float)(width*ex),(float)(height*ey));
        b.addStroke(new GestureDescription.StrokeDescription(path,0,time));
    }
}
