package co.nexus.lab.live;

import java.io.*;
import java.util.*;

/** Per-phase visual nearest-neighbour policy learned from user demonstrations. */
public final class MatchBook {
    public static final String[] PHASES={"Lobby","Despliegue","Partida","Resultados"};
    static final int LENGTH=16*9*3,MAX=160;
    public static final class Example{
        final int phase; final byte[] visual; final float x,y,u,v; final int millis;
        Example(int phase,byte[] visual,float x,float y,float u,float v,int millis){
            this.phase=phase;this.visual=visual.clone();this.x=x;this.y=y;this.u=u;this.v=v;this.millis=millis;
        }
    }
    final ArrayList<Example> examples=new ArrayList<>();
    public static byte[] describe(int[] pixels,int w,int h){
        byte[] f=new byte[LENGTH];int idx=0;
        for(int row=0;row<9;row++)for(int col=0;col<16;col++){
            int r=0,g=0,b=0;
            for(int j=0;j<4;j++)for(int i=0;i<4;i++){
                int x=(col*8+2*i+1)*w/128,y=h/7+(row*8+2*j+1)*(h-h/7)/72;
                int c=pixels[y*w+x];r+=c>>16&255;g+=c>>8&255;b+=c&255;
            }
            f[idx++]=(byte)(r/16);f[idx++]=(byte)(g/16);f[idx++]=(byte)(b/16);
        }
        return f;
    }
    private static boolean coordinate(float value){return value>=0&&value<=1;}
    public void add(int phase,byte[] f,float x,float y,float u,float v,int duration){
        if(phase<0||phase>3||f.length!=LENGTH||!coordinate(x)||!coordinate(y)||!coordinate(u)||!coordinate(v)||duration<40||duration>2000)throw new IllegalArgumentException();
        if(examples.size()>=MAX)throw new IllegalStateException("Perfil lleno");
        examples.add(new Example(phase,f,x,y,u,v,duration));
    }
    public boolean ready(){boolean[] have=new boolean[4];for(Example e:examples)have[e.phase]=true;for(boolean v:have)if(!v)return false;return true;}
    public Example choose(int phase,byte[] f){
        Example best=null;int distance=Integer.MAX_VALUE;
        for(Example e:examples){
            if(e.phase!=phase&&e.phase!=phase+1&&!(phase==1&&e.phase==3))continue;
            int d=0;for(int i=0;i<LENGTH;i++)d+=Math.abs((e.visual[i]&255)-(f[i]&255));
            if(d<distance){distance=d;best=e;}
        }
        if(best==null||distance>LENGTH*20)return null;
        for(Example other:examples){
            if(other==best||other.phase==best.phase||other.phase<phase||other.phase>phase+1)continue;
            int d=0;for(int i=0;i<LENGTH;i++)d+=Math.abs((other.visual[i]&255)-(f[i]&255));
            if(d<=distance+LENGTH*2)return null;
        }
        return best;
    }
    public void write(DataOutput d)throws IOException{
        d.writeInt(0x4e584d31);d.writeInt(examples.size());
        for(Example e:examples){d.writeByte(e.phase);d.write(e.visual);d.writeFloat(e.x);d.writeFloat(e.y);d.writeFloat(e.u);d.writeFloat(e.v);d.writeInt(e.millis);}
    }
    public static MatchBook read(DataInput d)throws IOException{
        if(d.readInt()!=0x4e584d31)throw new IOException();int n=d.readInt();if(n<0||n>MAX)throw new IOException();
        MatchBook b=new MatchBook();for(int i=0;i<n;i++){int phase=d.readUnsignedByte();byte[] f=new byte[LENGTH];d.readFully(f);
            try{b.add(phase,f,d.readFloat(),d.readFloat(),d.readFloat(),d.readFloat(),d.readInt());}catch(IllegalArgumentException ex){throw new IOException(ex);}
        }return b;
    }
}
