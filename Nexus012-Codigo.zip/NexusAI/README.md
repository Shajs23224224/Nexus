# NEXUS AI 0.5 · Controles visuales y campo de práctica 3D

El modo de partida por demostraciones se describe en [Partida aprendida](docs/PARTIDA-APRENDIDA.md).

La función **Prueba de controles en Free Fire** abre el cliente elegido y habilita una sesión de seguimiento por accesibilidad iniciada por el usuario. El manual está en [Controles en el juego](docs/CONTROLES-EN-EL-JUEGO.md). El botón independiente **Abrir Free Fire** mantiene la apertura manual. Las secciones siguientes documentan el campo de práctica de la versión 0.3, incluido en esta edición.

Aplicación Android para entrenar un agente visual local, observar su política con pesos fijos y enseñarle mediante controles táctiles. El campo utiliza cámara en primera persona, perspectiva, terreno y objetivos en tres dimensiones. El botón Abrir Free Fire inicia el cliente instalado para juego manual. Al cambiar a otra aplicación, NEXUS pausa su entrenamiento.

## Instalación y primera sesión

Extrae el ZIP y abre NEXUS-AI-0.5.apk. La edición 0.3 usa el identificador y el certificado de la edición 0.2 distribuida en esta conversación. Android puede instalarla como actualización y conservar el laboratorio 2D y sus pesos. El modelo 3D tiene arquitectura, memoria y pesos propios.

1. En el selector, elige **Seguimiento y mira**. Pulsa **Ver IA** para ver los controles que produce el modelo inicial entrenado. El marcador distingue los impactos de los intentos.
2. Pulsa **Entrenar** para que la política explore, reciba recompensas y actualice sus parámetros durante la práctica. **Circuito mixto** alterna los cuatro ejercicios por episodio.
3. En **Enseñar**, mantén presionado el lado izquierdo de la escena para avanzar. Mantén el derecho y desplaza el dedo respecto al punto inicial para girar o subir y bajar la cámara. Regresa al punto inicial o levanta el dedo para detener el giro. **Acción** marca el blanco o confirma la señal.
4. **Evaluar IA** congela los pesos y mide el número de objetivos completados en 16 semillas reservadas por ejercicio seleccionado. El circuito mezcla 64 episodios. Pausar o salir cancela una evaluación en curso.
5. **Recuperar modelo** recupera el punto guardado antes de la última sesión de entrenamiento o demostración. El guardado corriente se realiza al pausar y periódicamente durante el entrenamiento. Al reabrir se conservan los pesos y los contadores, y comienza un escenario nuevo.
6. **Analizar una grabación** abre el selector de Android. Elige un video propio, toca la región de interés y avanza fotograma a fotograma en intervalos de medio segundo. Un modelo de apariencia aprende una distribución de color a partir de tus etiquetas. El recuadro sugiere una región similar. Colores repetidos, iluminación y oclusión pueden producir falsos positivos. Este modelo es independiente del piloto 3D.
7. **Abrir Free Fire** intenta primero la edición estándar y después MAX. Si Android no encuentra una instalación accesible, la app lo indica. La partida del juego oficial queda bajo el control del usuario.

## Ejercicios

| Ejercicio | Condición de éxito |
|---|---|
| Puerta | Orientar la cámara, acercarse y cruzar el plano de una abertura entre paredes. |
| Seguimiento | Conseguir diez impactos sobre una diana móvil a altura variable antes de agotar el tiempo. Hay una espera de tres pasos entre intentos aceptados. |
| Recurso y zona | Alcanzar el recurso y llegar a la segunda marca antes del límite. El perímetro se estrecha y permanecer fuera reduce la vida. |
| Encuentro | Acercarse al marcador de un compañero simulado y confirmar durante cuatro pasos de una ventana de señal. |

Los episodios duran un máximo de 120 pasos. La cámara genera un fotograma RGB de 128 × 80 con un minimapa relativo a su orientación. El detector reconoce colores propios del simulador. El actor recibe características de la imagen y el ejercicio seleccionado. El simulador calcula por separado colisiones, impactos, salud y éxito. Las cuatro salidas coordinan giro, elevación, avance y acción en el mismo paso.

## Aprendizaje y reproducibilidad

La política tiene una capa oculta de 24 unidades tanh y cuatro salidas categóricas. El entrenamiento combina imitación de un tutor que usa las mismas observaciones visuales, repetición de hasta 256 demostraciones recientes y actualizaciones actor-crítico de un paso durante las acciones muestreadas por la política. Las recompensas reflejan, entre otras señales, impactos, progreso de misión, sincronización y resultado final. Los pesos y el crítico se guardan mediante AtomicFile. El búfer temporal de ejemplos vive en memoria. El botón Ver IA usa elecciones deterministas y conserva los pesos.

El APK incorpora una política inicial entrenada durante 640 episodios, con 78 401 actualizaciones. En el ensayo independiente de 128 escenarios por ejercicio, con semillas distintas de entrenamiento y validación de desarrollo, se obtuvieron estos resultados en la JVM con el código incluido en el APK.

| Ejercicio | Modelo congelado | Controles aleatorios |
|---|---:|---:|
| Puerta | 128/128 | 6/128 |
| Seguimiento | 128/128 | 0/128 |
| Recurso y zona | 127/128 | 0/128 |
| Encuentro | 128/128 | 2/128 |

La distribución de mapas, colores y movimiento es la de este simulador. El ensayo no mide competición contra humanos, rendimiento en Free Fire ni velocidad del Samsung Galaxy A21s.

## Código y pruebas

- FieldActivity contiene las pantallas nativas, controles, lanzador y gestión del ciclo de vida.
- El paquete co.nexus.lab.field contiene el mundo, la cámara, la percepción, la red y el ciclo de práctica. ReviewActivity decodifica videos previamente seleccionados por el usuario.
- El proyecto se abre en Android Studio y usa SDK 35, minSdk 26 y targetSdk 31. Para una compilación propia, usa el wrapper Gradle incluido. La compilación de distribución se firma independientemente.
- Con un JDK, ejecuta los siguientes comandos desde la raíz del proyecto para regenerar el modelo de referencia y evaluar un archivo de pesos. Se escribe en una carpeta temporal.

```sh
mkdir -p out
javac -d out app/src/main/java/co/nexus/lab/field/*.java tests/FieldBenchmark.java tests/FieldHoldout.java
java -cp out FieldBenchmark out/field-pilot.bin
java -cp out FieldHoldout app/src/main/assets/field-pilot.bin
```

Las pruebas anteriores del núcleo 2D siguen en tests/core.test.js y tests/interface_test.py. El manual específico de esa pantalla se encuentra en docs/LABORATORIO-2D.md. tests/android contiene la instrumentación de Android y un clip de prueba sintético.

## Alcance

El entrenamiento corresponde a la arena propia. El cliente oficial se abre mediante el mecanismo de lanzamiento de Android. Para controlar una partida oficial con IA sigue haciendo falta una interfaz de observación y acción autorizada por Garena. El modelo visual de paleta, el control de giro y el minimapa sintético están diseñados para los ejercicios incluidos. La transferencia a personajes, armas, escenarios, audio, inventario y escuadras reales, así como el rendimiento profesional en partidas, quedan sin demostrar.
