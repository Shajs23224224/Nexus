"use strict";
// Detector para la paleta de la arena propia. Una celda desconocida nunca se usa como suelo libre.
const Vision=(()=>{
  const palette=[['agente',[73,227,239]],['salida',[165,171,255]],['recurso',[240,191,125]],
    ['muro',[74,96,126]],['peligro',[109,66,65]],['suelo',[28,48,77]]];
  function scan(canvas){
    const {width,height}=canvas, pixels=canvas.getContext('2d').getImageData(0,0,width,height).data;
    const result=[],stamp=Date.now();
    for(let y=0;y<8;y++)for(let x=0;x<8;x++){
      for(const [kind,color] of palette){
        let score=0;
        for(const [dx,dy] of [[0,0],[6,0],[13,0],[-18,-18]]){
          const col=Math.floor((x+.5)*width/8)+dx,row=Math.floor((y+.5)*height/8)+dy;
          const i=(row*width+col)*4;
          const d=Math.max(...color.map((v,c)=>Math.abs(v-pixels[i+c])));
          score=Math.max(score,1-d/32);
        }
        if(score>.8){result.push({kind,x:(x+.5)/8,y:(y+.5)/8,score,stamp});break;}
      }
    }
    return result;
  }
  return {scan};
})();
