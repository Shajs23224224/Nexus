"use strict";
const Policy = (() => {
  const features=8, hidden=12, length=hidden*(features+1)+hidden+1, output=hidden*(features+1);
  function create(rng){return Array.from({length},()=>0.35*(rng()-0.5));}
  function forward(w,x,h) {
    let q=w[length-1];
    for(let j=0;j<hidden;j++){
      const k=j*(features+1);let sum=w[k+features];
      for(let i=0;i<features;i++)sum+=w[k+i]*x[i];
      const v=Math.tanh(sum);if(h)h[j]=v;q+=w[output+j]*v;
    }
    return q;
  }
  function best(w,state){
    const q=state.map(x=>forward(w,x));
    return q.indexOf(Math.max(...q));
  }
  function gradient(w,x,error,lr){
    const h=[];forward(w,x,h);
    const delta=Math.max(-1,Math.min(1,error))*lr;
    for(let j=0;j<hidden;j++){
      const k=j*(features+1),g=delta*w[output+j]*(1-h[j]*h[j]);
      for(let i=0;i<features;i++)w[k+i]+=g*x[i];
      w[k+features]+=g;w[output+j]+=delta*h[j];
    }
    w[length-1]+=delta;
  }
  function update(w,target,t,rate,gamma){
    const next=t.done?0:forward(target,t.next[best(w,t.next)]);
    const error=t.reward+gamma*next-forward(w,t.state[t.action]);
    gradient(w,t.state[t.action],error,rate);
    return Math.abs(error)<1?error*error/2:Math.abs(error)-0.5;
  }
  function imitate(w,state,action,rate){
    const q=state.map(x=>forward(w,x)), peak=Math.max(...q);
    const exp=q.map(v=>Math.exp(v-peak)),total=exp.reduce((a,b)=>a+b);
    for(let a=0;a<4;a++)gradient(w,state[a],+(a===action)-exp[a]/total,rate);
  }
  const valid=w=>Array.isArray(w)&&w.length===length&&w.every(v=>Number.isFinite(v)&&Math.abs(v)<10000);
  return {create,forward,best,update,imitate,valid,length};
})();
if(typeof module!=="undefined")module.exports=Policy;
