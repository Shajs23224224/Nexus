"use strict";
const Sim = (() => {
  const size = 8, dirs = [[0,-1],[1,0],[0,1],[-1,0]];
  function random(seed) {
    let value = seed >>> 0;
    const next = () => ((value = (Math.imul(value,1664525) + 1013904223) >>> 0) / 4294967296);
    next.state = () => value;
    return next;
  }
  const distance = (a,b) => Math.abs(a%size-b%size)+Math.abs((a>>3)-(b>>3));
  function neighbor(pos, action) {
    const [dx,dy] = dirs[action], x = pos%size+dx, y=(pos>>3)+dy;
    return x<0 || x>=size || y<0 || y>=size ? pos : y*size+x;
  }
  function connected(tiles,start) {
    const seen=new Set([start]), queue=[start];
    for(let i=0;i<queue.length;i++) for(let a=0;a<4;a++){
      const n=neighbor(queue[i],a);
      if(!seen.has(n) && tiles[n]!==1 && tiles[n]!==2){seen.add(n);queue.push(n);}
    }
    return seen;
  }
  function create(seed,level) {
    const rng=random(seed), cells=Array.from({length:64},(_,i)=>i);
    for(let i=63;i>0;i--){const j=Math.floor(rng()*(i+1));[cells[i],cells[j]]=[cells[j],cells[i]];}
    const [pos,exit,resource]=cells, tiles=Array(64).fill(0);
    for(const c of cells.slice(3,3+level*6)) {
      tiles[c]=level===2 && c%3===0?2:1;
      const reach=connected(tiles,pos);
      if(!reach.has(exit)||!reach.has(resource)) tiles[c]=0;
    }
    return {seed,level,pos,exit,resource,tiles,has:level<2,steps:0,score:0,done:false,won:false,previous:-1};
  }
  function observe(e) {
    const target=e.has?e.exit:e.resource;
    return dirs.map((_,a)=>{
      const n=neighbor(e.pos,a),blocked=n===e.pos||e.tiles[n]===1;
      return [1,(distance(e.pos,target)-distance(n,target)),+blocked,+(e.tiles[n]===2),
        +(n===target),+(n===e.previous),distance(n,target)/14,+e.has];
    });
  }
  const defaults={goal:5,danger:-3,step:-0.08,progress:0.24};
  function step(e,a,r=defaults) {
    if(e.done) throw Error('Episodio cerrado');
    const target=e.has?e.exit:e.resource, old=e.pos, next=neighbor(old,a);
    let reward=r.step;
    if(next===old || e.tiles[next]===1) reward-=0.45;
    else {e.pos=next;reward+=r.progress*(distance(old,target)-distance(next,target));}
    e.previous=old;e.steps++;
    if(e.tiles[e.pos]===2){reward+=r.danger;e.done=true;}
    if(!e.has && e.pos===e.resource){e.has=true;reward+=1;}
    if(e.has && e.pos===e.exit){e.won=true;e.done=true;reward+=r.goal;}
    if(e.steps>=48)e.done=true;
    e.score+=reward;return reward;
  }
  function heuristic(e) {
    const goal=e.has?e.exit:e.resource, queue=[[e.pos,-1]], seen=new Set([e.pos]);
    for(let i=0;i<queue.length;i++){
      const [p,first]=queue[i];
      for(let a=0;a<4;a++){
        const n=neighbor(p,a); if(seen.has(n)||e.tiles[n]!==0)continue;
        const f=first<0?a:first;if(n===goal)return f;seen.add(n);queue.push([n,f]);
      }
    }
    return 0;
  }
  return {create,observe,step,heuristic,random,defaults};
})();
if(typeof module!=="undefined")module.exports=Sim;
