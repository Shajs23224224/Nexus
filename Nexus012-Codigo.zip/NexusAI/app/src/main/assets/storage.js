"use strict";
const Vault=(()=>{
  const key='nexus.lab.v1.';
  function hash(text){
    let h=2166136261;
    for(let i=0;i<text.length;i++)h=Math.imul(h^text.charCodeAt(i),16777619);
    return (h>>>0).toString(16);
  }
  function save(m){
    const data=JSON.stringify(m), slot=localStorage.getItem(key+'head')==='a'?'b':'a';
    localStorage.setItem(key+slot,JSON.stringify({data,checksum:hash(data)}));
    localStorage.setItem(key+'head',slot);
  }
  function read(){
    const first=localStorage.getItem(key+'head')||'a';let damaged=false;
    for(const slot of [first,first==='a'?'b':'a']){
      try{
        const raw=localStorage.getItem(key+slot);if(!raw)continue;
        const obj=JSON.parse(raw);if(obj.checksum!==hash(obj.data))throw Error();
        const m=JSON.parse(obj.data);
        if(m.format!==1||![m.active,m.candidate,m.target].every(Policy.valid))throw Error();
        if(damaged)localStorage.setItem(key+'head',slot);
        return {model:m,notice:damaged?'Se recuperó el checkpoint anterior.':''};
      }catch(err){damaged=true;}
    }
    return {model:Lab.fresh(),notice:damaged?'Checkpoints ilegibles. Se inició un modelo nuevo.':''};
  }
  return {read,save,hash};
})();
