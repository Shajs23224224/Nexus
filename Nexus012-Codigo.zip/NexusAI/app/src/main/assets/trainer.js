"use strict";
const Lab = (() => {
  const sim=typeof require==='function'?require('./simulation.js'):Sim;
  const net=typeof require==='function'?require('./policy.js'):Policy;
  function fresh(seed=4292){
    const rng=sim.random(seed),w=net.create(rng);
    return {format:1,seed,rng:rng.state(),episodes:0,updates:0,version:1,level:0,
      active:w,candidate:w.slice(),target:w.slice(),history:[],demos:[],previous:null,
      replay:[],cursor:0,trace:[],loss:null,evaluation:null,rate:0.007,gamma:0.9,
      rewards:{...sim.defaults},profile:1,session:null,events:[],elapsed:0};
  }
  function cycle(m){
    const rng=sim.random(m.rng);
    if(!m.session)m.session=sim.create(Math.floor(rng()*0x40000000),m.level);
    const e=m.session,state=sim.observe(e),epsilon=Math.max(0.08,0.9*Math.exp(-m.episodes/90));
    const action=rng()<epsilon?Math.floor(rng()*4):net.best(m.candidate,state);
    const reward=sim.step(e,action,m.rewards),next=sim.observe(e);
    m.replay[m.cursor]={state,action,reward,next,done:e.done,seed:e.seed,version:m.version,at:Date.now()};
    m.cursor=(m.cursor+1)%256;
    let loss=0;
    for(let i=0;i<4;i++)
      loss+=net.update(m.candidate,m.target,m.replay[Math.floor(rng()*m.replay.length)],m.rate,m.gamma);
    m.loss=loss/4;
    if(++m.updates%40===0)m.target=m.candidate.slice();
    if(m.demos.length && m.updates%4===0){
      const d=m.demos[Math.floor(rng()*m.demos.length)];net.imitate(m.candidate,d.state,d.action,m.rate);
    }
    if(e.done){
      m.episodes++;
      m.trace.push({score:e.score,won:e.won,steps:e.steps,level:e.level});
      if(m.trace.length>80)m.trace.shift();
      m.session=null;
    }
    m.rng=rng.state();return e;
  }
  function evaluate(m,count=24){
    const table=[];
    for(let level=0;level<=m.level;level++){
      const results={};
      for(const name of ['candidate','active','random','heuristic']){
        let wins=0,steps=0,score=0;
        for(let i=0;i<count;i++){
          const seed=0xc0000000+i*7919+level*473,rng=sim.random(seed^123);
          const e=sim.create(seed,level);
          while(!e.done){
            const a=name==='random'?Math.floor(rng()*4):name==='heuristic'?sim.heuristic(e):net.best(m[name],sim.observe(e));
            sim.step(e,a,m.rewards);
          }
          wins+=+e.won;steps+=e.steps;score+=e.score;
        }
        results[name]={wins,count,steps:steps/count,score:score/count};
      }
      table.push(results);
    }
    return table;
  }
  function promote(m,table){
    const last=table[table.length-1],c=last.candidate,a=last.active;
    if(c.wins<=last.random.wins || c.wins/c.count<0.65 ||
        !(c.wins>a.wins || (c.wins===a.wins && c.steps<a.steps)) ||
        table.some(t=>t.candidate.wins<t.active.wins)) return false;
    m.previous={weights:m.active.slice(),version:m.version,level:m.level};
    m.active=m.candidate.slice();m.version++;
    m.history.push({version:m.version,at:Date.now(),level:m.level,wins:c.wins,count:c.count});
    m.history=m.history.slice(-20);
    if(c.wins/c.count>=0.85 && m.level<2){m.level++;m.session=null;}
    return true;
  }
  return {fresh,cycle,evaluate,promote};
})();
if(typeof module!=="undefined")module.exports=Lab;
