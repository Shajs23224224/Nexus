"use strict";
const $=id=>document.getElementById(id);
const loaded=Vault.read(),m=loaded.model;
let mode='pause',env=m.session||Sim.create(m.seed,m.level),timer=0,lastSave=0,lastSensor=0,device={},tab='arena';
const levels=['Movilidad','Navegación','Recolección'];
const msg=text=>{$('message').textContent=text;};
function log(text){m.events.unshift({at:Date.now(),text});m.events=m.events.slice(0,15);}
function persist(){
  try{Vault.save(m);lastSave=Date.now();return true;}
  catch(e){clearTimeout(timer);mode='pause';msg('No se pudo guardar. Exporta los pesos desde Modelos.');return false;}
}
function pause(note){
  clearTimeout(timer);mode='pause';if(note)msg(note);persist();render();
}
window.suspendLab=()=>pause('Sesión pausada. Puedes continuar desde el último paso.');
document.addEventListener('visibilitychange',()=>{if(document.hidden)window.suspendLab();});
function sensors(){
  try{device=window.Device?JSON.parse(Device.read()):{};}catch(e){device={};}
  lastSensor=Date.now();
}
function blocked(){
  if(Date.now()-lastSensor>1000)sensors();
  return device.foreground===false||device.lowMemory||device.thermal>=3||(device.battery<15&&!device.plugged);
}
function draw(e){
  const ctx=$('map').getContext('2d'),cell=48;
  ctx.fillStyle='#111b30';ctx.fillRect(0,0,384,384);
  for(let p=0;p<64;p++){
    const x=p%8*cell,y=(p>>3)*cell;
    ctx.fillStyle=e.tiles[p]===1?'#4a607e':e.tiles[p]===2?'#6d4241':'#1c304d';
    ctx.fillRect(x+1,y+1,cell-2,cell-2);
    ctx.fillStyle='#304968';ctx.fillRect(x+23,y+23,2,2);
    if(e.tiles[p]===2){ctx.strokeStyle='#e19e80';ctx.beginPath();ctx.moveTo(x+14,y+34);ctx.lineTo(x+33,y+15);ctx.stroke();}
  }
  function center(pos){return [(pos%8+.5)*cell,((pos>>3)+.5)*cell];}
  function ring(pos,r,color,width){
    const [x,y]=center(pos);ctx.beginPath();ctx.arc(x,y,r,0,2*Math.PI);ctx.strokeStyle=color;ctx.lineWidth=width;ctx.stroke();
  }
  ring(e.exit,13,'#a5abff',3);ring(e.exit,6,'#a5abff',2);
  if(!e.has){const [x,y]=center(e.resource);ctx.fillStyle='#f0bf7d';ctx.beginPath();ctx.moveTo(x,y-10);ctx.lineTo(x+10,y);ctx.lineTo(x,y+10);ctx.lineTo(x-10,y);ctx.closePath();ctx.fill();}
  const [x,y]=center(e.pos);ring(e.pos,16,'#27768d',2);ctx.fillStyle='#49e3ef';ctx.beginPath();ctx.arc(x,y,9,0,2*Math.PI);ctx.fill();
  $('mission').textContent=levels[e.level]+' · '+(e.has?'Alcanza la salida':'Recoge el recurso');
  $('step').textContent=e.steps+' / 48';
}
function plot(){
  const c=$('plot').getContext('2d'),v=m.trace.map(t=>t.score);
  c.clearRect(0,0,600,110);
  if(!v.length){$('plotcaption').textContent='La curva aparecerá al completar el primer episodio.';return;}
  const lo=Math.min(0,...v),hi=Math.max(1,...v);
  const y=n=>100-90*(n-lo)/(hi-lo);
  c.strokeStyle='#425473';c.beginPath();c.moveTo(8,y(0));c.lineTo(592,y(0));c.stroke();
  c.beginPath();v.forEach((s,i)=>{const x=8+584*i/Math.max(1,v.length-1);if(i)c.lineTo(x,y(s));else c.moveTo(x,y(s));});c.strokeStyle='#49e3ef';c.lineWidth=3;c.stroke();
  $('plotcaption').textContent='Últimos '+v.length+' episodios · media '+(v.reduce((a,b)=>a+b)/v.length).toFixed(2);
}
function render(){
  $('status').textContent=({train:'● Entrenando',watch:'● Observando',manual:'● Enseñando',pause:'○ En pausa'})[mode];
  $('episodes').textContent=m.episodes;$('memory').textContent=m.replay.length;$('version').textContent='v'+m.version;
  $('manual').hidden=mode!=='manual';$('stop').disabled=mode==='pause';$('train').disabled=mode==='train';
  if(tab==='arena'){draw(env);plot();}
}
function validate(){
  const level=m.level,table=Lab.evaluate(m),version=m.version;
  const approved=Lab.promote(m,table);
  m.evaluation={table,level,version,at:Date.now(),approved};
  const text=approved?'Candidato aprobado como v'+m.version+'.':'Evaluación completada. Se conserva v'+m.version+'.';
  log(text);msg(text);$('modelmsg').textContent=text;persist();modelPage();return approved;
}
function tick(){
  if(mode!=='train'&&mode!=='watch')return;
  if(blocked()){pause('Sesión pausada por el estado del dispositivo.');return;}
  if(mode==='train'){
    const start=performance.now();
    const steps=[2,8,18][m.profile];
    for(let i=0;i<steps;i++){
      env=Lab.cycle(m);
      if(env.done && m.episodes%40===0)validate();
      if(mode!=='train'||performance.now()-start>20)break;
    }
    m.elapsed+=performance.now()-start;
  }else{
    if(env.done)env=Sim.create((Math.random()*0x40000000)>>>0,m.level);
    Sim.step(env,Policy.best(m.active,Sim.observe(env)),m.rewards);
  }
  if(Date.now()-lastSave>4500 && !persist()){render();return;}
  render();if(tab==='settings')telemetry();
  timer=setTimeout(tick,mode==='watch'?250:[130,65,35][m.profile]);
}
function start(next){
  clearTimeout(timer);sensors();
  if(blocked()){pause('Sesión pausada por batería, memoria, temperatura o estado de la app.');return;}
  mode=next;if(next!=='train')env=Sim.create((Math.random()*0x40000000)>>>0,m.level);
  msg(next==='train'?'Se valida el candidato cada 40 episodios.':next==='watch'?'El modelo activo recorre la arena.':'Usa las flechas para registrar ejemplos.');
  render();if(mode!=='manual')tick();
}
$('train').onclick=()=>start('train');$('watch').onclick=()=>start('watch');$('teach').onclick=()=>start('manual');
$('stop').onclick=()=>pause('Pausa solicitada. Progreso guardado.');
document.querySelectorAll('[data-a]').forEach(b=>b.onclick=()=>{
  if(mode!=='manual')return;
  const a=Number(b.dataset.a);
  m.demos.push({state:Sim.observe(env),action:a,seed:env.seed});m.demos=m.demos.slice(-256);
  Sim.step(env,a,m.rewards);msg('Ejemplos guardados: '+m.demos.length);
  if(env.done){pause(env.won?'Demostración completada.':'Fin de la demostración.');return;}
  persist();render();
});
$('undo').onclick=()=>{m.demos.pop();persist();msg('Ejemplos guardados: '+m.demos.length);};
function line(label,value){const row=document.createElement('div');row.className='line';const b=document.createElement('b');b.textContent=value;row.append(document.createTextNode(label),b);return row;}
function modelPage(){
  const out=$('results');out.replaceChildren();const ev=m.evaluation;
  if(ev){ev.table.forEach((group,index)=>{
    const h=document.createElement('h2');h.textContent=levels[index];out.append(h);
    const table=document.createElement('table');table.innerHTML='<tr><th>Política</th><th>Éxitos</th><th>Pasos¹</th><th>Retorno¹</th></tr>';
    for(const [id,name] of [['candidate','Candidato'],['active','Activa v'+ev.version],['random','Aleatoria'],['heuristic','Ruta mínima']]){
      const r=group[id],tr=table.insertRow();for(const v of [name,r.wins+'/'+r.count,r.steps.toFixed(1),r.score.toFixed(2)])tr.insertCell().textContent=v;
    }out.append(table);
  });
  const p=document.createElement('p');p.textContent='¹ Media por episodio. Evaluado '+new Date(ev.at).toLocaleString('es')+'.';out.append(p);}
  else out.textContent='Todavía no hay una evaluación registrada.';
  $('versions').replaceChildren(...m.history.slice().reverse().map(v=>line('v'+v.version+' · '+levels[v.level],v.restored?'Desde v'+v.restored:v.wins+'/'+v.count)));
  if(!m.history.length)$('versions').textContent='v1 · Inicialización local';
  $('rollback').disabled=!m.previous;
}
$('evaluate').onclick=()=>{pause();validate();render();};
$('rollback').onclick=()=>{
  if(!m.previous)return;pause();
  const old=m.previous;m.active=old.weights;m.candidate=m.active.slice();m.target=m.active.slice();m.level=old.level;m.previous=null;m.session=null;
  // A restoration receives a fresh revision so version identifiers stay unique.
  m.version++;m.evaluation=null;env=Sim.create(m.seed,m.level);
  m.history.push({version:m.version,level:m.level,at:Date.now(),restored:old.version});m.history=m.history.slice(-20);
  log('v'+m.version+' restaurada desde v'+old.version);$('modelmsg').textContent=m.events[0].text;
  persist();modelPage();render();
};
$('export').onclick=()=>{const data=JSON.stringify(m.active);$('exchange').value=JSON.stringify({format:'nexus-q1',weights:m.active,checksum:Vault.hash(data)});$('exchange').select();$('modelmsg').textContent='Pesos listos para copiar.';};
$('import').onclick=()=>{
  try{
    const f=JSON.parse($('exchange').value);
    if(f.format!=='nexus-q1'||!Policy.valid(f.weights)||Vault.hash(JSON.stringify(f.weights))!==f.checksum)throw Error();
    pause();m.candidate=f.weights.slice();m.target=m.candidate.slice();m.evaluation=null;persist();modelPage();
    $('modelmsg').textContent='Candidato importado. Evalúalo para decidir su activación.';
  }catch(e){$('modelmsg').textContent='Modelo incompatible o suma de comprobación incorrecta.';}
};
function fields(){for(const [id,v] of Object.entries({rate:m.rate,gamma:m.gamma,goal:m.rewards.goal,danger:m.rewards.danger,cost:m.rewards.step,progress:m.rewards.progress}))$(id).value=v;$('profile').selectedIndex=m.profile;}
$('apply').onclick=()=>{
  const inputs=['rate','gamma','goal','danger','cost','progress'];
  if(inputs.some(id=>!$(id).value||!$(id).checkValidity())){$('setmsg').textContent='Revisa los valores fuera de rango.';return;}
  pause();const rewards={goal:+$('goal').value,danger:+$('danger').value,step:+$('cost').value,progress:+$('progress').value};
  if(JSON.stringify(rewards)!==JSON.stringify(m.rewards)){m.replay=[];m.cursor=0;m.session=null;m.trace=[];m.evaluation=null;}
  m.rate=+$('rate').value;m.gamma=+$('gamma').value;m.profile=$('profile').selectedIndex;m.rewards=rewards;
  persist();$('setmsg').textContent='Configuración guardada.';telemetry();
};
$('defaults').onclick=()=>{const f=Lab.fresh();for(const [k,v] of Object.entries({goal:f.rewards.goal,danger:f.rewards.danger,cost:f.rewards.step,progress:f.rewards.progress,rate:f.rate,gamma:f.gamma}))$(k).value=v;$('profile').selectedIndex=1;$('apply').click();};
function telemetry(){
  if(Date.now()-lastSensor>1500)sensors();
  const rows=[['Red neuronal','8 → 12 → 1 por acción'],['Parámetros',Policy.length],['Actualizaciones (lote de 4)',m.updates],['Pérdida Huber',m.loss===null?'—':m.loss.toFixed(4)],['Cómputo de entrenamiento',(m.elapsed/1000).toFixed(1)+' s'],['Demostraciones',m.demos.length],['Batería',device.battery==null?'Sin lectura':device.battery+' %'],['Estado térmico Android',device.thermal??'Sin lectura'],['Memoria disponible',device.ram==null?'Sin lectura':device.ram+' MiB'],['ABI',device.abi||'Sin lectura']];
  $('telemetry').replaceChildren(...rows.map(([a,b])=>line(a,b)));$('events').replaceChildren(...m.events.map(e=>line(new Date(e.at).toLocaleTimeString('es'),e.text)));
}
document.querySelectorAll('[data-tab]').forEach(b=>b.onclick=()=>{
  tab=b.dataset.tab;for(const id of ['arena','models','settings'])$(id).hidden=id!==tab;
  document.querySelectorAll('[data-tab]').forEach(n=>{if(n===b)n.setAttribute('aria-current','page');else n.removeAttribute('aria-current');});
  if(tab==='settings'){fields();telemetry();}if(tab==='models')modelPage();
  render();window.scrollTo(0,0);
});
$('scan').onclick=()=>{
  const found=Vision.scan($('map'));
  const counts={};for(const obj of found)counts[obj.kind]=(counts[obj.kind]||0)+1;
  $('vision').textContent=Object.entries(counts).map(([k,v])=>k+' '+v).join(' · ')+' · sin clasificar '+(64-found.length);
};
fields();msg(loaded.notice);render();
