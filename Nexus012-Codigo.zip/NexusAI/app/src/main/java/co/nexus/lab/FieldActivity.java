package co.nexus.lab;

import android.app.*;
import android.content.*;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.os.*;
import android.util.AtomicFile;
import android.view.*;
import android.widget.*;
import co.nexus.lab.field.*;
import co.nexus.lab.field.Camera;
import java.io.*;
import java.util.Random;

public final class FieldActivity extends Activity {
    private static final int BG=0xff081226,PANEL=0xff15263f,INK=0xfff1f6ff,MUTED=0xffb0c1d8,AQUA=0xff51f5df;
    private final Handler handler=new Handler(Looper.getMainLooper());
    private final Random seeds=new Random();
    private Pilot pilot;
    private Practice practice;
    private int mode=0,mission=0,localWins=0,localRuns=0,round;
    private static final String[] MENU={"Cruzar la puerta","Seguimiento y mira","Recurso y zona","Encuentro de escuadra","Circuito mixto"};
    private long savedUpdates, sensorTime;
    private boolean active,limited;
    private TextView status,stats;
    private Stage stage;
    private LinearLayout root;
    private Thread worker;
    private int generation;
    private String message="";
    private final int[] manual={1,1,0,0};
    private AtomicFile file,backup;
    @Override public void onCreate(Bundle state){
        super.onCreate(state);
        getWindow().setStatusBarColor(BG); getWindow().setNavigationBarColor(BG);
        file=new AtomicFile(new File(getFilesDir(),"field-policy.bin"));
        backup=new AtomicFile(new File(getFilesDir(),"field-previous.bin"));
        try{pilot=load(file);}catch(IOException e){
            try(DataInputStream in=new DataInputStream(getAssets().open("field-pilot.bin"))){pilot=Pilot.read(in);}
            catch(IOException ignored){pilot=new Pilot(41);}
            if(file.getBaseFile().exists())message="Se recuperó el modelo inicial después de un error de lectura.";
        }
        savedUpdates=pilot.updates;
        mission=getPreferences(0).getInt("mission",0);if(mission<0||mission>=MENU.length)mission=0;
        localRuns=getPreferences(0).getInt("runs",0);localWins=getPreferences(0).getInt("wins",0);
        practice=nextPractice();
        ScrollView scroll=new ScrollView(this);scroll.setBackgroundColor(BG);root=new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);root.setPadding(dp(16),dp(12),dp(16),dp(24));scroll.addView(root);setContentView(scroll);
        LinearLayout brand=new LinearLayout(this);brand.setGravity(Gravity.CENTER_VERTICAL);
        ImageView mark=new ImageView(this);mark.setImageResource(R.drawable.nexus_mark);brand.addView(mark,dp(42),dp(42));
        TextView word=label("  NEXUS AI",19,INK);word.setLetterSpacing(.12f);brand.addView(word);root.addView(brand);
        root.addView(label("Campo de práctica 3D",29,INK));
        Spinner select=new Spinner(this);ArrayAdapter<String> options=new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,MENU);
        select.setAdapter(options);select.setSelection(mission);root.addView(select,-1,dp(48));
        stage=new Stage();root.addView(stage,-1,dp(211));
        status=label("",15,AQUA);stats=label("",13,MUTED);root.addView(status);root.addView(stats);
        LinearLayout controls=row();button(controls,"Entrenar",()->start(1),true);button(controls,"Ver IA",()->start(2),false);button(controls,"Pausar",()->stop("En pausa"),false);
        LinearLayout teaching=row();button(teaching,"Enseñar",()->start(3),false);button(teaching,"Acción",()->{
            if(mode==3){manual[3]=1;return;}note("En Enseñar, usa Acción para marcar el blanco o confirmar el encuentro.");
        },false);
        root.addView(label("En Enseñar, mantén el lado izquierdo para avanzar y arrastra el derecho para girar o elevar la mira.",13,MUTED));
        LinearLayout models=row();button(models,"Evaluar IA",this::evaluate,false);button(models,"Recuperar modelo",this::rollback,false);
        root.addView(label("Free Fire",22,INK));
        root.addView(label("Abre el juego para una partida manual. Al salir de NEXUS se pausa el campo de práctica.",14,MUTED));
        if(android.os.Build.VERSION.SDK_INT>=28)
            button(row(),"Análisis de video",()->startActivity(new Intent(this,co.nexus.video.Review.class)),false);
        button(row(),"Prueba de controles en Free Fire",()->startActivity(new Intent(this,co.nexus.lab.live.LiveSetup.class)),true);
        button(row(),"Abrir Free Fire",this::launchGame,false);
        button(row(),"Analizar una grabación",()->startActivity(new Intent(this,ReviewActivity.class)),false);
        button(row(),"Laboratorio 2D y modelos anteriores",()->startActivity(new Intent(this,NexusActivity.class)),false);
        select.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener(){
            public void onNothingSelected(AdapterView<?> parent){}
            public void onItemSelected(AdapterView<?> parent,View v,int i,long id){
                if(i==mission)return;stop("Ejercicio seleccionado");mission=i;round=0;practice=nextPractice();
                getPreferences(0).edit().putInt("mission",i).apply();draw();
            }
        });
        draw();
    }
    private Practice nextPractice(){
        int exercise=mission==4?(round++%4):mission;
        return new Practice(exercise,seeds.nextLong());
    }
    private int dp(int x){return Math.round(x*getResources().getDisplayMetrics().density);}
    private TextView label(String text,int size,int color){
        TextView t=new TextView(this);t.setText(text);t.setTextColor(color);t.setTextSize(size);t.setPadding(0,dp(5),0,dp(5));return t;
    }
    private LinearLayout row(){LinearLayout r=new LinearLayout(this);r.setPadding(0,dp(4),0,dp(4));root.addView(r);return r;}
    private void button(LinearLayout row,String text,Runnable task,boolean primary){
        Button b=new Button(this);b.setAllCaps(false);b.setText(text);b.setTextSize(14);b.setMinWidth(0);b.setMinimumWidth(0);b.setPadding(dp(4),0,dp(4),0);
        GradientDrawable g=new GradientDrawable();g.setCornerRadius(dp(10));g.setColor(primary?AQUA:PANEL);b.setBackground(g);
        b.setTextColor(primary?BG:INK);b.setOnClickListener(v->task.run());
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,-2,1);lp.setMargins(0,0,dp(4),0);row.addView(b,lp);
    }
    private void launchGame(){
        String[] packages={"com.dts.freefireth","com.dts.freefiremax"};
        for(String pkg:packages){
            Intent i=getPackageManager().getLaunchIntentForPackage(pkg);if(i==null)continue;
            try{startActivity(i);return;}catch(ActivityNotFoundException|SecurityException ignored){}
        }
        note("Android no encontró Free Fire ni Free Fire MAX disponibles para abrir.");
        Toast.makeText(this,message,Toast.LENGTH_LONG).show();
    }
    private void note(String s){message=s;draw();}
    private void draw(){
        status.setText(new String[]{"En pausa","Entrenamiento local","Evaluación visual · pesos fijos","Demostración manual"}[mode]+"  ·  "+practice.field.ticks+"/"+Field.LIMIT);
        int exercise=practice.field.mission;
        String extra=exercise==1?" · Aciertos "+practice.field.hits+"/"+practice.field.shots:exercise==2?" · "+(practice.field.stage==0?"Busca el recurso":"Alcanza la zona")+" · Vida "+practice.field.health:exercise==3?" · "+(practice.field.signal()?"Señal activa":"Espera la señal"):"";
        stats.setText("Prácticas locales "+localRuns+" · Éxitos "+localWins+extra+(mission==4?" · "+Field.NAMES[exercise]:"")+"\nActualizaciones del modelo "+pilot.updates+(message.isEmpty()?"":"\n"+message));
        stage.invalidate();
    }
    private void start(int m){
        if(mode==m)return;
        stop("");if(resourceLimit()){note("Sesión pausada por batería, memoria o temperatura.");return;}
        if(m!=2){try{store(backup,pilot);}catch(IOException e){note("No se pudo crear el punto de recuperación.");return;}}
        mode=m;if(practice.field.done)practice=nextPractice();handler.post(tick);
    }
    private boolean resourceLimit(){
        long now=SystemClock.elapsedRealtime();if(now-sensorTime<2000)return limited;sensorTime=now;
        Intent battery=registerReceiver(null,new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
        limited=false;
        if(battery!=null){
            int scale=battery.getIntExtra(BatteryManager.EXTRA_SCALE,100),v=battery.getIntExtra(BatteryManager.EXTRA_LEVEL,100);
            limited=scale>0 && v>=0 && 100*v/scale<15 && battery.getIntExtra(BatteryManager.EXTRA_PLUGGED,0)==0;
        }
        if(Build.VERSION.SDK_INT>=29)limited|=getSystemService(PowerManager.class).getCurrentThermalStatus()>=3;
        ActivityManager.MemoryInfo mem=new ActivityManager.MemoryInfo();getSystemService(ActivityManager.class).getMemoryInfo(mem);limited|=mem.lowMemory;return limited;
    }
    private final Runnable tick=new Runnable(){public void run(){
        if(mode==0||!active)return;if(resourceLimit()){stop("Pausa de recursos");return;}
        int count=mode==1?3:1;
        for(int i=0;i<count;i++){
            if(practice.field.done)practice=nextPractice();
            practice.tick(pilot,mode!=2,mode==3?manual:null);
            manual[3]=0;
            if(practice.field.done){localRuns++;if(practice.field.won)localWins++;
                message=practice.field.won?"Objetivo completado":"Tiempo agotado";
                getPreferences(0).edit().putInt("runs",localRuns).putInt("wins",localWins).apply();
                if(mode==3){stop(message);return;}break;
            }
        }
        if(pilot.updates-savedUpdates>=150 && !save()){stop("Error al guardar el modelo");return;}
        draw();handler.postDelayed(this,mode==1?50:85);
    }};
    private static Pilot load(AtomicFile f)throws IOException{try(DataInputStream in=new DataInputStream(f.openRead())){return Pilot.read(in);}}
    private static void store(AtomicFile f,Pilot p)throws IOException{
        FileOutputStream stream=f.startWrite();
        try{DataOutputStream out=new DataOutputStream(stream);p.write(out);out.flush();f.finishWrite(stream);}
        catch(IOException e){f.failWrite(stream);throw e;}
    }
    private boolean save(){
        if(savedUpdates==pilot.updates)return true;
        try{store(file,pilot);savedUpdates=pilot.updates;return true;}catch(IOException e){return false;}
    }
    private void stop(String msg){
        mode=0;handler.removeCallbacks(tick);generation++;if(worker!=null)worker.interrupt();
        manual[0]=1;manual[1]=1;manual[2]=0;manual[3]=0;
        message=save()?msg:"No se pudo guardar el último avance.";draw();
    }
    private void rollback(){
        stop("");try{Pilot old=load(backup);store(file,old);pilot=old;savedUpdates=old.updates;note("Modelo anterior a la última sesión recuperado.");}
        catch(IOException e){note("No se pudo recuperar una sesión anterior.");}
    }
    private void evaluate(){
        stop("");final int token=generation,m=mission;
        final Pilot frozen;
        try{ByteArrayOutputStream b=new ByteArrayOutputStream();pilot.write(new DataOutputStream(b));
            frozen=Pilot.read(new DataInputStream(new ByteArrayInputStream(b.toByteArray())));}
        catch(IOException e){note("No se pudo leer el modelo.");return;}
        note(m==4?"Evaluando 64 escenarios reservados…":"Evaluando 16 escenarios reservados…");
        worker=new Thread(()->{
            int wins=0,hits=0,shots=0;
            int total=m==4?64:16;
            for(int i=0;i<total;i++){
                int exercise=m==4?i%4:m;
                Practice e=new Practice(exercise,0x700c221L+7919L*i+exercise);
                while(!e.field.done){if(Thread.currentThread().isInterrupted())return;e.tick(frozen,false,null);}
                if(e.field.won)wins++;hits+=e.field.hits;shots+=e.field.shots;
            }
            final String result="Evaluación: "+wins+"/"+total+" objetivos"+(m==1?" · impactos "+hits+"/"+shots:"");
            runOnUiThread(()->{if(token==generation&&active)note(result);});
        });worker.start();
    }
    @Override protected void onPause(){active=false;stop("Sesión pausada");super.onPause();}
    @Override protected void onResume(){super.onResume();active=true;}
    private final class Stage extends View{
        private final Bitmap buffer=Bitmap.createBitmap(Camera.W,Camera.H,Bitmap.Config.ARGB_8888);
        private final Paint paint=new Paint();private final RectF dest=new RectF();
        private int look=-1,move=-1;private float lx,ly;
        Stage(){super(FieldActivity.this);setContentDescription("Vista en primera persona con minimapa y retícula");}
        protected void onDraw(Canvas c){
            buffer.setPixels(practice.frame(),0,Camera.W,0,0,Camera.W,Camera.H);
            c.drawColor(BG);float scale=Math.min(getWidth()/(float)Camera.W,getHeight()/(float)Camera.H);
            float w=Camera.W*scale,h=Camera.H*scale,x=(getWidth()-w)/2,y=(getHeight()-h)/2;
            dest.set(x,y,x+w,y+h);paint.setColor(-1);c.drawBitmap(buffer,null,dest,paint);
            float cx=getWidth()/2f,cy=getHeight()/2f;paint.setColor(0xffffffff);
            c.drawLine(cx-6,cy,cx-2,cy,paint);c.drawLine(cx+2,cy,cx+6,cy,paint);c.drawLine(cx,cy-6,cx,cy-2,paint);
        }
        @Override public boolean onTouchEvent(android.view.MotionEvent e){
            if(mode!=3)return false;
            int a=e.getActionMasked(),i=e.getActionIndex(),id=e.getPointerId(i);
            if(a==MotionEvent.ACTION_DOWN||a==MotionEvent.ACTION_POINTER_DOWN){
                getParent().requestDisallowInterceptTouchEvent(true);
                if(e.getX(i)<getWidth()/2f){move=id;manual[2]=1;}
                else{look=id;lx=e.getX(i);ly=e.getY(i);}
            }else if(a==MotionEvent.ACTION_MOVE&&look>=0){
                int j=e.findPointerIndex(look);if(j>=0){float dx=e.getX(j)-lx,dy=ly-e.getY(j);
                    manual[0]=dx>dp(8)?2:dx<-dp(8)?0:1;manual[1]=dy>dp(8)?2:dy<-dp(8)?0:1;}
            }else if(a==MotionEvent.ACTION_UP||a==MotionEvent.ACTION_POINTER_UP||a==MotionEvent.ACTION_CANCEL){
                if(id==look||a==MotionEvent.ACTION_CANCEL){look=-1;manual[0]=manual[1]=1;}
                if(id==move||a==MotionEvent.ACTION_CANCEL){move=-1;manual[2]=0;}
                if(look<0&&move<0)getParent().requestDisallowInterceptTouchEvent(false);
            }
            return true;
        }
    }
}
