package co.nexus.lab;

import android.app.Activity;
import android.content.SharedPreferences;
import android.graphics.*;
import android.os.Handler;
import android.view.View;
import android.widget.*;
import java.util.Random;

/** Lightweight recovery arena when Android's web renderer exits. */
final class NativeArena extends LinearLayout {
    private final Random rng = new Random();
    private final double[] weights = new double[4];
    private final Handler clock = new Handler();
    private final SharedPreferences prefs;
    private final TextView stats;
    private final View arena;
    private final NexusActivity.Monitor monitor;
    private int pos, goal, steps, episodes, wins;
    private boolean running;

    NativeArena(Activity activity, NexusActivity.Monitor monitor) {
        super(activity);
        this.monitor = monitor;
        prefs = activity.getSharedPreferences("recovery.policy.v1", 0);
        for (int i=0;i<weights.length;i++) weights[i]=prefs.getFloat("w"+i,0);
        episodes=prefs.getInt("episodes",0); wins=prefs.getInt("wins",0);
        reset();
        setOrientation(VERTICAL); int pad = (int)(16 * getResources().getDisplayMetrics().density);
        setPadding(pad,pad,pad,pad); setBackgroundColor(0xff080e21);
        LinearLayout brand = new LinearLayout(activity);
        brand.setGravity(android.view.Gravity.CENTER_VERTICAL);
        ImageView logo = new ImageView(activity);
        logo.setImageResource(co.nexus.lab.R.drawable.nexus_mark);
        brand.addView(logo,new LayoutParams(pad*3,pad*3));
        TextView wordmark = new TextView(activity);
        wordmark.setText("NEXUS AI"); wordmark.setLetterSpacing(.12f); wordmark.setTextSize(18);
        wordmark.setPadding(pad,0,0,0); wordmark.setTextColor(0xff49e3ef);
        brand.addView(wordmark); addView(brand);
        TextView title=new TextView(activity); title.setText("Arena ligera");title.setPadding(0,pad,0,0);title.setTextSize(30);addView(title);
        TextView info=new TextView(activity);info.setText("Modo de recuperación · Movilidad. Este agente guarda su propio entrenamiento local.");info.setPadding(0,0,0,pad);info.setTextColor(0xffacbcd6);addView(info);
        arena=new View(activity) {
            private final Paint pen=new Paint(Paint.ANTI_ALIAS_FLAG);
            @Override protected void onDraw(Canvas c){
                float cell=Math.min(getWidth(),getHeight())/8f;
                for(int p=0;p<64;p++){
                    float x=(p%8)*cell,y=(p/8)*cell;
                    pen.setColor(0xff1c304d);c.drawRect(x+1,y+1,x+cell-1,y+cell-1,pen);
                    if(p==goal){pen.setColor(0xffa5abff);c.drawCircle(x+cell/2,y+cell/2,cell*.3f,pen);}
                    if(p==pos){pen.setColor(0xff49e3ef);c.drawCircle(x+cell/2,y+cell/2,cell*.2f,pen);}
                }
            }
        };
        addView(arena,new LayoutParams(-1,0,1));
        stats=new TextView(activity);addView(stats);
        Button train=new Button(activity);train.setText("Entrenar IA");train.setOnClickListener(new OnClickListener(){public void onClick(View v){if(!running){running=true;tick.run();}}});train.setBackgroundTintList(android.content.res.ColorStateList.valueOf(0xff49e3ef));train.setTextColor(0xff080e21);addView(train);
        Button stop=new Button(activity);stop.setText("Pausar");stop.setOnClickListener(new OnClickListener(){public void onClick(View v){pause();}});stop.setBackgroundTintList(android.content.res.ColorStateList.valueOf(0xff233755));addView(stop);
        show();
    }
    private void reset(){pos=rng.nextInt(64);do{goal=rng.nextInt(64);}while(pos==goal);steps=0;}
    private int distance(int p){return Math.abs(p%8-goal%8)+Math.abs(p/8-goal/8);}
    private int next(int p,int a){
        if(a==0 && p>=8)return p-8;
        if(a==1 && p%8<7)return p+1;
        if(a==2 && p<56)return p+8;
        if(a==3 && p%8>0)return p-1;
        return p;
    }
    private double[] features(int p,int a){int n=next(p,a);return new double[]{1,distance(p)-distance(n),n==p?1:0,n==goal?1:0};}
    private double value(double[] x){double v=0;for(int i=0;i<4;i++)v+=weights[i]*x[i];return Math.tanh(v);}
    private int best(int p){
        int choice=0;double max=-2;
        for(int a=0;a<4;a++){double v=value(features(p,a));if(v>max){max=v;choice=a;}}
        return choice;
    }
    private void step(){
        int a=rng.nextDouble()<.15?rng.nextInt(4):best(pos),n=next(pos,a);
        double[] x=features(pos,a);
        double prediction=value(x), reward=n==goal?1:n==pos?-.45:-.04+.12*(distance(pos)-distance(n));
        boolean done=n==goal||++steps>=48;
        double target=reward+(done?0:.85*value(features(n,best(n))));
        for(int i=0;i<4;i++)weights[i]+=.025*(target-prediction)*(1-prediction*prediction)*x[i];
        pos=n;if(done){episodes++;if(pos==goal)wins++;reset();save();}
    }
    private final Runnable tick=new Runnable(){public void run(){
        if(!running)return;
        try{
            org.json.JSONObject d=new org.json.JSONObject(monitor.read());
            if(d.optBoolean("lowMemory")||d.optInt("thermal")>=3||
                (d.optInt("battery",100)<15&&!d.optBoolean("plugged"))){pause();return;}
        }catch(org.json.JSONException ignored){}
        for(int i=0;i<4;i++)step();show();clock.postDelayed(this,150);
    }};
    private void save(){
        SharedPreferences.Editor edit=prefs.edit().putInt("episodes",episodes).putInt("wins",wins);
        for(int i=0;i<4;i++)edit.putFloat("w"+i,(float)weights[i]);
        edit.apply();
    }
    private void show(){stats.setText((running?"Entrenando":"En pausa")+" · Episodios "+episodes+" · Éxitos "+wins);arena.invalidate();}
    void pause(){running=false;clock.removeCallbacks(tick);save();show();}
}
