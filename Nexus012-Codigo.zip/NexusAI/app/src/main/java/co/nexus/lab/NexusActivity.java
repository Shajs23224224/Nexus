package co.nexus.lab;

import android.app.Activity;
import android.app.ActivityManager;
import android.content.*;
import android.os.*;
import android.webkit.*;
import org.json.JSONObject;

public final class NexusActivity extends Activity {
    private WebView view;
    private NativeArena recovery;
    private volatile boolean foreground;
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(0xff080e21);
        if (getIntent().getBooleanExtra("lightweight", false)) { openRecovery(); return; }
        view = new WebView(this);
        view.setBackgroundColor(0xff080e21);
        WebSettings settings = view.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowContentAccess(false);
        settings.setAllowFileAccessFromFileURLs(false);
        settings.setAllowUniversalAccessFromFileURLs(false);
        settings.setBlockNetworkLoads(true);
        view.setWebViewClient(new WebViewClient() {
            @Override public boolean onRenderProcessGone(WebView failed, RenderProcessGoneDetail detail) {
                openRecovery();
                failed.destroy();
                view = null;
                return true;
            }
            @Override public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) { return true; }
        });
        view.addJavascriptInterface(new Monitor(), "Device");
        setContentView(view);
        view.loadUrl("file:///android_asset/index.html");
    }
    private void openRecovery() {
        recovery = new NativeArena(this, new Monitor());
        setContentView(recovery);
    }
    public final class Monitor {
        @JavascriptInterface public String read() {
            JSONObject out = new JSONObject();
            try {
                Intent b = registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
                if (b != null) {
                    int scale = b.getIntExtra(BatteryManager.EXTRA_SCALE, 0);
                    int level = b.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
                    if (level >= 0 && scale > 0) out.put("battery", level * 100 / scale);
                    out.put("plugged", b.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) != 0);
                }
                if (Build.VERSION.SDK_INT >= 29)
                    out.put("thermal", getSystemService(PowerManager.class).getCurrentThermalStatus());
                ActivityManager.MemoryInfo mem = new ActivityManager.MemoryInfo();
                getSystemService(ActivityManager.class).getMemoryInfo(mem);
                out.put("ram", mem.availMem / 1048576);
                out.put("lowMemory", mem.lowMemory);
                out.put("foreground", foreground);
                out.put("abi", android.text.TextUtils.join(", ", Build.SUPPORTED_ABIS));
            } catch (Exception ignored) { /* Missing sensor values stay absent. */ }
            return out.toString();
        }
    }
    @Override public void onPause() {
        foreground = false;
        if (recovery != null) recovery.pause();
        if (view != null) {
            view.evaluateJavascript("window.suspendLab && window.suspendLab()", null);
            view.onPause();
        }
        super.onPause();
    }
    @Override public void onResume() { super.onResume(); foreground = true; if(view != null) view.onResume(); }
    @Override public void onDestroy() { if(view != null){ view.removeJavascriptInterface("Device"); view.destroy(); } super.onDestroy(); }
}
