package co.nexus.lab;

import android.app.Activity;
import android.content.*;
import android.graphics.*;
import android.media.MediaMetadataRetriever;
import android.net.Uri;
import android.os.Bundle;
import android.view.*;
import android.widget.*;
import java.util.concurrent.*;

/** Human-labelled, offline review of user-selected video. No screen capture or external input service. */
public final class ReviewActivity extends Activity {
    private final ExecutorService jobs=Executors.newSingleThreadExecutor();
    private final float[] bins=new float[64];
    private ClipView frame;
    private TextView caption;
    private Uri uri;
    private long ms,duration;
    private int token,examples;
    private boolean ready;
    private int bestX=-1,bestY;
    private Bitmap current;
    private int dp(int v){return Math.round(v*getResources().getDisplayMetrics().density);}
    @Override public void onCreate(Bundle state){
        super.onCreate(state);getWindow().setStatusBarColor(0xff081226);
        ScrollView scroll=new ScrollView(this);LinearLayout root=new LinearLayout(this);root.setOrientation(1);root.setPadding(dp(16),dp(16),dp(16),dp(16));
        root.setBackgroundColor(0xff081226);scroll.addView(root);setContentView(scroll);
        TextView title=new TextView(this);title.setTextSize(26);title.setText("Observación de partidas");root.addView(title);
        TextView desc=new TextView(this);desc.setText("Elige una grabación propia. Toca el objeto que quieres seguir y avanza medio segundo. El recuadro propone una región de color similar.");root.addView(desc);
        Button open=new Button(this);open.setText("Elegir video");root.addView(open);
        open.setOnClickListener(v->{Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT).setType("video/*").addCategory(Intent.CATEGORY_OPENABLE);
            try{startActivityForResult(i,1);}catch(ActivityNotFoundException ex){caption.setText("El selector de archivos no está disponible.");}});
        frame=new ClipView();root.addView(frame,-1,dp(245));caption=new TextView(this);root.addView(caption);
        LinearLayout row=new LinearLayout(this);root.addView(row);
        for(int dir:new int[]{-1,1}){Button b=new Button(this);b.setText(dir<0?"−0,5 s":"+0,5 s");row.addView(b,new LinearLayout.LayoutParams(0,-2,1));b.setOnClickListener(v->{
            if(uri!=null && ready){ms=Math.max(0,Math.min(Math.max(0,duration-1),ms+dir*500));decode();}
        });}
        SharedPreferences p=getPreferences(0);examples=p.getInt("examples",0);for(int i=0;i<64;i++)bins[i]=p.getFloat("bin"+i,0);
        caption.setText("Ejemplos de apariencia guardados: "+examples);
    }
    @Override protected void onActivityResult(int request,int result,Intent data){
        super.onActivityResult(request,result,data);if(request==1&&result==RESULT_OK&&data!=null&&data.getData()!=null){uri=data.getData();ms=0;decode();}
    }
    private void decode(){
        final Uri selected=uri;final long time=ms;final int id=++token;ready=false;caption.setText("Leyendo fotograma…");
        jobs.execute(()->{
            MediaMetadataRetriever r=new MediaMetadataRetriever();Bitmap out=null;long len=0;
            try{
                r.setDataSource(this,selected);len=Long.parseLong(r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION));
                if(android.os.Build.VERSION.SDK_INT>=27){
                    int width=Integer.parseInt(r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH));
                    int height=Integer.parseInt(r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT));
                    if(width<=0||height<=0)throw new IllegalArgumentException();
                    double factor=Math.min(1,384.0/Math.max(width,height));
                    out=r.getScaledFrameAtTime(time*1000,MediaMetadataRetriever.OPTION_CLOSEST,
                        Math.max(1,(int)Math.round(width*factor)),Math.max(1,(int)Math.round(height*factor)));
                }else{
                    Bitmap full=r.getFrameAtTime(time*1000,MediaMetadataRetriever.OPTION_CLOSEST);
                    if(full!=null){float scale=Math.min(1,384f/Math.max(full.getWidth(),full.getHeight()));
                        out=Bitmap.createScaledBitmap(full,Math.max(1,Math.round(full.getWidth()*scale)),Math.max(1,Math.round(full.getHeight()*scale)),true);
                        if(full!=out)full.recycle();}
                }
            }catch(Exception|OutOfMemoryError ignored){}finally{try{r.release();}catch(Exception ignored){}}
            final Bitmap result=out;final long length=len;runOnUiThread(()->{
                if(id!=token||isFinishing()||isDestroyed()){if(result!=null)result.recycle();return;}
                if(current!=null)current.recycle();current=result;duration=length;ready=result!=null;
                if(ready){locate();status("");}else{bestX=-1;caption.setText("No se pudo decodificar este fotograma. Prueba un video MP4 compatible.");}
                frame.invalidate();
            });
        });
    }
    private void status(String end){caption.setText(String.format(java.util.Locale.ROOT,"%.1f / %.1f s · %d ejemplos%s",ms/1000.,duration/1000.,examples,end));}
    private static int bin(int c){return ((c>>18)&0x30)|((c>>12)&0xc)|((c>>6)&3);}
    private void annotate(int x,int y){
        float[] counts=new float[64];int n=0;
        for(int j=Math.max(0,y-6);j<=Math.min(current.getHeight()-1,y+6);j++)for(int i=Math.max(0,x-6);i<=Math.min(current.getWidth()-1,x+6);i++){counts[bin(current.getPixel(i,j))]++;n++;}
        float rate=examples==0?1:.25f;SharedPreferences.Editor p=getPreferences(0).edit();
        for(int i=0;i<64;i++){bins[i]=(1-rate)*bins[i]+rate*counts[i]/n;p.putFloat("bin"+i,bins[i]);}
        p.putInt("examples",++examples).apply();bestX=x;bestY=y;status(" · región etiquetada");frame.invalidate();
    }
    private void locate(){
        bestX=-1;if(examples==0)return;
        double best=0;
        for(int y=4;y<current.getHeight()-4;y+=5)for(int x=4;x<current.getWidth()-4;x+=5){
            double score=0;
            for(int dy=-4;dy<=4;dy+=4)for(int dx=-4;dx<=4;dx+=4)score+=bins[bin(current.getPixel(x+dx,y+dy))];
            if(score>best){best=score;bestX=x;bestY=y;}
        }
    }
    @Override protected void onDestroy(){token++;jobs.shutdownNow();super.onDestroy();}
    private final class ClipView extends View{
        final Paint pen=new Paint(1);final RectF dest=new RectF();
        ClipView(){super(ReviewActivity.this);}
        protected void onDraw(Canvas c){
            c.drawColor(0xff142139);if(current==null)return;float scale=Math.min(getWidth()/(float)current.getWidth(),getHeight()/(float)current.getHeight());
            float w=scale*current.getWidth(),h=scale*current.getHeight(),left=(getWidth()-w)/2,top=(getHeight()-h)/2;dest.set(left,top,left+w,top+h);
            pen.setStyle(Paint.Style.FILL);pen.setColor(-1);c.drawBitmap(current,null,dest,pen);
            if(bestX>=0){pen.setColor(0xff51f5df);pen.setStyle(Paint.Style.STROKE);pen.setStrokeWidth(dp(2));c.drawRect(left+(bestX-6)*scale,top+(bestY-6)*scale,left+(bestX+6)*scale,top+(bestY+6)*scale,pen);}
        }
        public boolean onTouchEvent(MotionEvent e){
            if(e.getAction()==MotionEvent.ACTION_UP&&ready&&current!=null&&dest.contains(e.getX(),e.getY()))
                annotate((int)((e.getX()-dest.left)*current.getWidth()/dest.width()),(int)((e.getY()-dest.top)*current.getHeight()/dest.height()));
            return true;
        }
    }
}
