package co.nexus.lab.field;

import java.util.Arrays;

/** Perspective RGB image with a camera-relative minimap drawn into the same pixels. */
public final class Camera {
    public static final int W=128,H=80, TARGET=0xff51f5df, MAP=0xffffb458, LAMP=0xffd799ff;
    static final int MX=111,MY=16,R=12;
    public final int[] pixels=new int[W*H];
    private final double[] depth=new double[W*H];
    private double sy,cy,sp,cp;
    private void rect(int x,int y,int w,int h,int color){
        for(int j=Math.max(0,y);j<Math.min(H,y+h);j++)
            Arrays.fill(pixels,j*W+Math.max(0,x),j*W+Math.min(W,x+w),color);
    }
    private void box(Field e,double x,double y,double z,double width,double height,int color){
        double dx=x-e.x,dz=z-e.z,dy=y-e.eye;
        double forward=dx*sy+dz*cy,side=dx*cy-dz*sy;
        double d=forward*cp+dy*sp;
        if(d<.15)return;
        double sx=W*.5+76*side/d,screenY=H*.5-76*(dy*cp-forward*sp)/d;
        double rw=Math.max(.7,38*width/d),rh=Math.max(.7,38*height/d);
        int left=Math.max(0,(int)Math.ceil(sx-rw)),right=Math.min(W-1,(int)Math.floor(sx+rw));
        int top=Math.max(0,(int)Math.ceil(screenY-rh)),bottom=Math.min(H-1,(int)Math.floor(screenY+rh));
        for(int j=top;j<=bottom;j++)for(int i=left;i<=right;i++){
            int k=j*W+i;if(d<=depth[k]){depth[k]=d;pixels[k]=color;}
        }
    }
    public void render(Field e){
        sy=Math.sin(e.yaw);cy=Math.cos(e.yaw);sp=Math.sin(e.pitch);cp=Math.cos(e.pitch);
        Arrays.fill(depth,Double.POSITIVE_INFINITY);
        for(int y=0;y<H;y++){
            double vertical=(H*.5-y)/76,up=vertical*cp+sp;
            if(up>=-.005){Arrays.fill(pixels,y*W,(y+1)*W,(y<H/3?0xff243e67:0xff365575));continue;}
            double d=-e.eye/up,f=d*(cp-vertical*sp);
            for(int x=0;x<W;x++){
                double side=(x-W*.5)*d/76,wx=e.x+cy*side+sy*f,wz=e.z-sy*side+cy*f;
                boolean line=Math.abs(wx-Math.rint(wx))<.025||Math.abs(wz-Math.rint(wz))<.025;
                int tile=((int)Math.floor(wx/2)+(int)Math.floor(wz/2))&1;
                pixels[y*W+x]=line?0xff304866:tile==0?0xff1a2f45:0xff1b334c;
            }
        }
        for(int i=-4;i<=4;i++){
            box(e,i*4,1.25,20,1.4,2.5,0xff536781);
            box(e,-14,1.1,i*4,1.4,2.2,0xff34485f);
        }
        if(e.mission==Field.ZONE && e.stage==1){
            double radius=e.zoneRadius();
            for(int i=0;i<48;i++){
                double angle=i*Math.PI/24;
                box(e,e.tx+radius*Math.sin(angle),.12,e.tz+radius*Math.cos(angle),.24,.24,0xff9ba2ff);
            }
        }
        if(e.mission==Field.DOOR){
            for(int i=-15;i<=15;i++)if(i!=0)box(e,e.tx+i*1.6,1.25,e.tz,1.1,2.5,0xff667b96);
            box(e,e.tx,2.8,e.tz,2.5,.35,TARGET);
            box(e,e.tx-1.15,1.35,e.tz,.22,2.7,TARGET);
            box(e,e.tx+1.15,1.35,e.tz,.22,2.7,TARGET);
        }else{
            if(e.mission==Field.TRACK||e.mission==Field.TEAM)
                box(e,e.tx,e.ty-.64,e.tz,.72,.86,0xff8193dd);
            box(e,e.tx,e.ty,e.tz,e.mission==Field.TRACK?.50:.66,e.mission==Field.TRACK?.50:.75,TARGET);
        }
        rect(MX-R-2,MY-R-2,2*R+5,2*R+5,0xff091427);
        double dx=e.tx-e.x,dz=e.tz-e.z,dist=Math.hypot(dx,dz);
        double scale=Math.min(1.4,R/Math.max(.01,dist));
        int mx=MX+(int)Math.round((dx*cy-dz*sy)*scale),my=MY-(int)Math.round((dx*sy+dz*cy)*scale);
        rect(MX,MY,1,1,0xffeeeeff);rect(mx-1,my-1,3,3,MAP);
        if(e.mission==Field.TEAM&&e.signal())rect(2,2,4,4,LAMP);
    }
}
