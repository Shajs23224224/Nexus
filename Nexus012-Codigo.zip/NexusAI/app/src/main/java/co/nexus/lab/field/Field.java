package co.nexus.lab.field;

import java.util.Random;

/** Internal 3-D practice field, in metres. Only the renderer and the scorer see world coordinates. */
public final class Field {
    public static final int DOOR=0, TRACK=1, ZONE=2, TEAM=3, LIMIT=120;
    public static final String[] NAMES={"Cruzar la puerta","Seguimiento y mira","Recurso y zona","Encuentro de escuadra"};
    public final int mission;
    final double startX,startZ,phase,eye=1.55;
    public double x,z,yaw,pitch,tx,tz,ty;
    public int ticks,hits,shots,stage,sync;
    public boolean done,won;
    public int health=100;
    private int acquiredAt,cooldown;
    public double zoneRadius(){return Math.max(.9,13.0-(ticks-acquiredAt)*.18);}
    public Field(int mission,long seed){
        this.mission=mission;
        Random rng=new Random(seed);
        startX=rng.nextDouble()*10-5;startZ=5+rng.nextDouble()*6;
        phase=rng.nextDouble()*6.28;
        yaw=(rng.nextDouble()-.5)*(mission==TRACK?1.4:5.6);
        pitch=(rng.nextDouble()-.5)*.45;
        target();
    }
    void target(){
        tx=startX;tz=startZ;ty=1.55;
        if(mission==TRACK){
            tx+=2*Math.sin(phase+ticks*.065);
            ty=2.6+1.2*Math.sin(phase+ticks*.095);tz+=Math.cos(phase+ticks*.05);
        }
        if(mission==ZONE && stage==1){tx=-startX-3;tz=14;}
        if(mission==TEAM){tx+=.8*Math.sin(phase+ticks*.05);ty=1.8;}
    }
    public boolean signal(){return (ticks/12)%2==1;}
    public static double bound(double v,double a,double b){return Math.max(a,Math.min(b,v));}
    public void step(int[] a){
        if(done)return;
        yaw+=(a[0]-1)*.085;
        pitch=bound(pitch+(a[1]-1)*.052,-.72,.72);
        if(a[2]==1){
            double nx=bound(x+.38*Math.sin(yaw),-18,18),nz=bound(z+.38*Math.cos(yaw),-8,22);
            boolean wall=mission==DOOR && (z-startZ)*(nz-startZ)<=0 && Math.abs(nx-startX)>1.1;
            if(!wall){x=nx;z=nz;}
        }
        double range=Math.hypot(tx-x,tz-z);
        if(mission==DOOR && z>=startZ && Math.abs(x-startX)<=1.1)won=true;
        if(cooldown>0)cooldown--;
        if(mission==TRACK && a[3]==1 && cooldown==0){
            cooldown=3;
            shots++;
            double bearing=Math.atan2(tx-x,tz-z)-yaw;
            double elevation=Math.atan2(ty-eye,range);
            if(Math.cos(bearing)>.995 && Math.abs(elevation-pitch)<.085)hits++;
        }
        if(mission==TRACK && hits>=10)won=true;
        if(mission==ZONE && range<1.0){if(stage==1)won=true;else {stage=1;acquiredAt=ticks;}}
        if(mission==TEAM){
            if(range<1.25 && signal() && a[3]==1)sync++;
            else if(!signal() || range>=1.25)sync=0;
            if(sync>=4)won=true;
        }
        if(mission==ZONE && stage==1 && range>zoneRadius())health=Math.max(0,health-2);
        ticks++;done=won||health==0||ticks>=LIMIT;target();
    }
}
