package co.nexus.lab.field;

import java.io.*;
import java.util.Random;

/** Online imitation of a visual tutor. Four independent categorical control heads. */
public final class Pilot {
    static final int IN=Sight.N,H=24,OUT=10;
    static final int[] widths={3,3,2,2};
    private final double[][] hidden=new double[H][IN],head=new double[OUT][H+1];
    private final double[] latent=new double[H],prob=new double[OUT],error=new double[H];
    private final Random random;
    private final double[][] replay=new double[256][IN];
    private final int[][] labels=new int[256][4];
    private int cursor,count;
    private final double[] critic=new double[IN];
    public long updates, episodes;
    public Pilot(long seed){
        random=new Random(seed);
        for(double[] row:hidden)for(int i=0;i<row.length;i++)row[i]=(random.nextDouble()-.5)*.65;
        for(double[] row:head)for(int i=0;i<row.length;i++)row[i]=(random.nextDouble()-.5)*.4;
    }
    private void forward(double[] x){
        for(int j=0;j<H;j++){double y=0;for(int i=0;i<IN;i++)y+=hidden[j][i]*x[i];latent[j]=Math.tanh(y);}
        int index=0;
        for(int width:widths){
            double maximum=-Double.MAX_VALUE,sum=0;
            for(int a=index;a<index+width;a++){
                double y=head[a][H];for(int j=0;j<H;j++)y+=head[a][j]*latent[j];
                prob[a]=y;maximum=Math.max(maximum,y);
            }
            for(int a=index;a<index+width;a++){prob[a]=Math.exp(prob[a]-maximum);sum+=prob[a];}
            for(int a=index;a<index+width;a++)prob[a]/=sum;
            index+=width;
        }
    }
    public int[] act(double[] x){
        forward(x);int[] out=new int[4];int offset=0;
        for(int k=0;k<4;k++){
            int best=0;for(int i=1;i<widths[k];i++)if(prob[offset+i]>prob[offset+best])best=i;
            out[k]=best;offset+=widths[k];
        }
        return out;
    }
    /** Draw on-policy actions for the autonomous part of training. */
    public int[] sample(double[] x,Random rng){
        forward(x);int[] action=new int[4];int offset=0;
        for(int k=0;k<4;k++){
            double dice=rng.nextDouble();int a=0;
            while(a<widths[k]-1 && (dice-=prob[offset+a])>0)a++;
            action[k]=a;offset+=widths[k];
        }
        return action;
    }
    private double value(double[] x){
        double sum=0;for(int i=0;i<IN;i++)sum+=critic[i]*x[i];return sum;
    }
    /** One-step actor-critic using the observed outcome. Demonstrations update the supervised loss separately. */
    public void reinforce(double[] before,int[] action,double reward,double[] after,boolean done){
        double advantage=Field.bound(reward+(done?0:.94*value(after))-value(before),-2,2);
        for(int i=0;i<IN;i++)critic[i]+=.004*advantage*before[i];
        forward(before);int offset=0;
        for(int k=0;k<4;k++){
            for(int i=0;i<widths[k];i++){
                int a=offset+i;double step=.0015*advantage*((i==action[k]?1:0)-prob[a]);
                for(int j=0;j<H;j++)head[a][j]+=step*latent[j];
                head[a][H]+=step;
            }
            offset+=widths[k];
        }
        updates++;
    }
    private void fit(double[] x,int[] goal){
        forward(x);java.util.Arrays.fill(error,0);int offset=0;
        for(int k=0;k<4;k++){
            for(int i=0;i<widths[k];i++){
                int a=i+offset;double delta=(i==goal[k]?1:0)-prob[a];
                for(int j=0;j<H;j++){
                    error[j]+=delta*head[a][j];
                    head[a][j]+=.018*delta*latent[j];
                }
                head[a][H]+=.018*delta;
            }
            offset+=widths[k];
        }
        for(int j=0;j<H;j++){
            double d=.013*error[j]*(1-latent[j]*latent[j]);
            for(int i=0;i<IN;i++)hidden[j][i]+=d*x[i];
        }
        updates++;
    }
    public void learn(double[] x,int[] label){
        System.arraycopy(x,0,replay[cursor],0,IN);System.arraycopy(label,0,labels[cursor],0,4);
        cursor=(cursor+1)%replay.length;count=Math.min(count+1,replay.length);
        fit(x,label);int i=random.nextInt(count);fit(replay[i],labels[i]);
    }
    public void write(DataOutput out)throws IOException{
        out.writeInt(0x4e583332);out.writeLong(updates);out.writeLong(episodes);
        for(double w:critic)out.writeDouble(w);
        for(double[][] matrix:new double[][][]{hidden,head})for(double[] row:matrix)for(double w:row)out.writeDouble(w);
    }
    public static Pilot read(DataInput in)throws IOException{
        if(in.readInt()!=0x4e583332)throw new IOException("Formato inválido");
        Pilot p=new Pilot(903);p.updates=in.readLong();p.episodes=in.readLong();
        if(p.episodes<0||p.updates<0)throw new IOException("Contadores inválidos");
        for(int i=0;i<IN;i++){p.critic[i]=in.readDouble();if(!Double.isFinite(p.critic[i])||Math.abs(p.critic[i])>1000)throw new IOException("Crítico inválido");}
        for(double[][] matrix:new double[][][]{p.hidden,p.head})for(double[] row:matrix)for(int i=0;i<row.length;i++){
            double w=in.readDouble();if(!Double.isFinite(w)||Math.abs(w)>1000)throw new IOException("Pesos inválidos");row[i]=w;
        }
        return p;
    }
}
