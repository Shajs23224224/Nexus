package co.nexus.lab.field;

import java.util.Random;

/** Uses the same control and observation loop on the phone and in the JVM benchmark. */
public final class Practice {
    private final Camera camera=new Camera();
    private final Sight sight=new Sight(),after=new Sight();
    public final Field field;
    private final Random mix;
    public Practice(int mission,long seed){
        field=new Field(mission,seed);mix=new Random(seed^245176);camera.render(field);
    }
    public int[] frame(){return camera.pixels;}
    public void tick(Pilot pilot,boolean train,int[] manual){
        if(field.done)return;
        sight.read(camera.pixels,field.mission);
        boolean autonomous=train && manual==null && mix.nextDouble()>=(pilot.episodes<60?.60:.18);
        int[] action=manual!=null?manual:autonomous?pilot.sample(sight.v,mix):pilot.act(sight.v);
        int priorHits=field.hits,priorStage=field.stage,priorSync=field.sync,priorShots=field.shots;
        int[] tutor=train?(manual!=null?manual:sight.demonstration(field.mission)):null;
        if(train && !autonomous)action=tutor;
        field.step(action);camera.render(field);
        if(train){
            if(autonomous){
                after.read(camera.pixels,field.mission);
                double reward=-.01+(field.won?2:field.done?-1:0)+.6*(field.hits-priorHits)
                    +.6*(field.stage-priorStage)+.08*(field.sync-priorSync)-.025*(field.shots-priorShots);
                pilot.reinforce(sight.v,action,reward,after.v,field.done);
            }
            pilot.learn(sight.v,tutor);
            if(field.done)pilot.episodes++;
        }
    }
}
