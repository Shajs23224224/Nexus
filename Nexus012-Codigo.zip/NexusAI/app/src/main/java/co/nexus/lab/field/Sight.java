package co.nexus.lab.field;

/** No access to the world or the simulator seed. Reads RGB plus the selected exercise. */
public final class Sight {
    public static final int N=16;
    public final double[] v=new double[N];
    public void read(int[] rgb,int mission){
        int count=0,sx=0,sy=0,mx=0,my=0,nmap=0;
        for(int k=0;k<rgb.length;k++){
            int color=rgb[k];
            if(color==Camera.TARGET){count++;sx+=k%Camera.W;sy+=k/Camera.W;}
            else if(color==Camera.MAP){nmap++;mx+=k%Camera.W;my+=k/Camera.W;}
        }
        v[0]=count>0?1:0;
        v[1]=count==0?0:(sx/(double)count-Camera.W*.5)/(Camera.W*.5);
        v[2]=count==0?0:(Camera.H*.5-sy/(double)count)/(Camera.H*.5);
        v[3]=Math.min(1,count/120.0);
        v[4]=nmap==0?0:(mx/(double)nmap-Camera.MX)/Camera.R;
        v[5]=nmap==0?0:(Camera.MY-my/(double)nmap)/Camera.R;
        v[6]=Math.hypot(v[4],v[5]);
        v[7]=rgb[2*Camera.W+2]==Camera.LAMP?1:0;
        for(int i=0;i<4;i++)v[8+i]=mission==i?1:0;
        v[12]=1;
        v[13]=v[6]<.15?1:0;
        v[14]=Math.abs(v[1])<.10&&Math.abs(v[2])<.12?1:0;
        v[15]=Math.atan2(v[4],v[5])/Math.PI;
    }
    public int[] demonstration(int mission){
        double horizontal=v[4],forward=v[5];
        if(mission==Field.TRACK&&v[0]>0)horizontal=v[1];
        int yaw=horizontal<-.055?0:horizontal>.055?2:1;
        if(forward<-.1&&yaw==1)yaw=2;
        int pitch=1,move=0,interact=0;
        if(mission==Field.TRACK){
            if(v[0]>0){pitch=v[2]<-.075?0:v[2]>.075?2:1;interact=Math.abs(v[1])<.10&&Math.abs(v[2])<.12?1:0;}
        }else{
            move=forward>=0 && Math.abs(horizontal)<.38?1:0;
            if(mission==Field.TEAM&&v[6]<.15){move=0;interact=v[7]>0?1:0;}
        }
        return new int[]{yaw,pitch,move,interact};
    }
}
