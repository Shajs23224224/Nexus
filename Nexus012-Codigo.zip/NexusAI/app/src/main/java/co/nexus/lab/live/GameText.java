package co.nexus.lab.live;

import java.util.Locale;
import java.text.Normalizer;

final class GameText {
    boolean finished, noKit, emptyMagazine, noReserve;
    void read(CharSequence label){
        if(label==null || label.length()>96)return;
        String s=Normalizer.normalize(label.toString(),Normalizer.Form.NFD)
                .replaceAll("\\p{M}+","").trim().toLowerCase(Locale.ROOT);
        switch(s){
            case "fin de la partida": case "partida finalizada": case "match over":
            case "booyah!": finished=true;break;
            case "sin botiquines":case "no medkits":noKit=true;break;
            case "cargador vacio":case "magazine empty":emptyMagazine=true;break;
            case "sin municion":case "out of ammo":noReserve=true;break;
        }
    }
}
