package co.nexus.lab.live;

import android.accessibilityservice.*;
import android.app.KeyguardManager;
import android.content.*;
import android.graphics.*;
import android.hardware.HardwareBuffer;
import android.os.*;
import android.util.DisplayMetrics;
import android.view.*;
import android.view.accessibility.*;
import android.widget.*;
import android.util.AtomicFile;
import java.io.*;

/** User-started visual tracking experiment. All callbacks are serialized on the main looper. */
public final class LiveService extends AccessibilityService {
    static LiveService connected;
    private final Handler loop=new Handler(Looper.getMainLooper());
    private final Tracker tracker=new Tracker();
    private final int[] rgb=new int[Tracker.W*Tracker.H];
    private final float[] camera=new float[2],stick=new float[2],fire=new float[2],mark=new float[2];
    private String game;
    private int mode,phase,unknown,repeat;
    private MatchBook book;private MatchBook.Example previous;
    private byte[] pending;private boolean reading;
    private Button phaseKey,runKey;
    private AtomicFile profile(String pkg){return new AtomicFile(new File(getFilesDir(),"partida-"+pkg+".bin"));}
    boolean prepare(String pkg,boolean move,boolean tap,int requested){
        MatchBook loaded=new MatchBook();
        if(requested==1||requested==2){
            try(DataInputStream in=new DataInputStream(profile(pkg).openRead())){loaded=MatchBook.read(in);}
            catch(FileNotFoundException absent){}catch(IOException damaged){return false;}
            if(requested==2&&!loaded.ready())return false;
        }
        arm(pkg,move,tap);mode=requested;book=loaded;phase=unknown=repeat=0;previous=null;reading=false;return game!=null;
    }
    private boolean persist(){
        AtomicFile f=profile(game);FileOutputStream stream=null;
        try{stream=f.startWrite();DataOutputStream out=new DataOutputStream(stream);book.write(out);out.flush();f.finishWrite(stream);return true;}
        catch(IOException e){if(stream!=null)f.failWrite(stream);return false;}
    }
    private boolean move,tap,entered,tracking,chosen;
    private int generation,width,height,step,gestures,adjustments;
    private double gx,gy,prevX,prevY,cmdX,cmdY;
    private long deadline,nextTap,unavailableSince;
    private WindowManager wm;
    private LinearLayout bar;
    private FrameLayout picker;
    private Button calibrate;
    private TextView info;
    private String summary="";
    @Override protected void onServiceConnected(){connected=this;wm=getSystemService(WindowManager.class);}
    @Override public void onInterrupt(){end("Sesión interrumpida.");}
    @Override public void onDestroy(){end("Servicio desconectado.");if(connected==this)connected=null;super.onDestroy();}
    private boolean foreground(){
        if(game==null||getSystemService(KeyguardManager.class).isKeyguardLocked()||!getSystemService(PowerManager.class).isInteractive())return false;
        // An accessibility overlay can be the most recently touched window. Identify the
        // underlying app, and suspend while a focused system dialog or keyboard covers it.
        for(AccessibilityWindowInfo win:getWindows()){
            int type=win.getType();
            if(type==AccessibilityWindowInfo.TYPE_ACCESSIBILITY_OVERLAY)continue;
            if(type==AccessibilityWindowInfo.TYPE_INPUT_METHOD || (type==AccessibilityWindowInfo.TYPE_SYSTEM&&win.isFocused()))return false;
            if(type!=AccessibilityWindowInfo.TYPE_APPLICATION)continue;
            AccessibilityNodeInfo root=win.getRoot();
            if(root==null)return false;
            try{return root.getPackageName()!=null && game.contentEquals(root.getPackageName());}
            finally{root.recycle();}
        }
        return false;
    }
    void arm(String pkg,boolean movement,boolean action){
        end("");if(Build.VERSION.SDK_INT<30||!("com.dts.freefireth".equals(pkg)||"com.dts.freefiremax".equals(pkg)))return;
        game=pkg;move=movement;tap=action;deadline=SystemClock.elapsedRealtime()+60000;
        gx=getSharedPreferences("live",0).getFloat(pkg+".gx",1);gy=getSharedPreferences("live",0).getFloat(pkg+".gy",1);
        gestures=adjustments=0;entered=false;nextTap=0;loop.post(guard);
    }
    private void checkWindow(){
        if(!entered||game==null)return;
        if(foreground()){unavailableSince=0;return;}
        // Window metadata can briefly be empty as the gesture picker is removed.
        // Stop all action immediately; wait for a stable departure before removing the bar.
        if(unavailableSince==0)unavailableSince=SystemClock.elapsedRealtime();
        if(mode==1&&(tracking||reading))matchIdle("Ventana en transición");
        if(SystemClock.elapsedRealtime()-unavailableSince>=2200)end("El juego salió de primer plano.");
    }
    private final Runnable guard=new Runnable(){public void run(){
        if(game==null)return;
        if(SystemClock.elapsedRealtime()>deadline){end("Tiempo de sesión agotado.");return;}
        if(!foreground()){if(entered){checkWindow();if(game==null)return;}}
        else if(!entered){unavailableSince=0;entered=true;deadline=SystemClock.elapsedRealtime()+(mode==0?600000:2700000);try{showBar();}catch(RuntimeException e){end("Panel no disponible.");return;}}
        else if(tracking && !sameDisplay()){end("La pantalla cambió de orientación.");return;}
        if(entered&&foreground())unavailableSince=0;
        loop.postDelayed(this,320);
    }};
    @Override public void onAccessibilityEvent(AccessibilityEvent e){
        if(entered && game!=null && e.getEventType()==AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED)checkWindow();
    }
    private DisplayMetrics metrics(){DisplayMetrics d=new DisplayMetrics();wm.getDefaultDisplay().getRealMetrics(d);return d;}
    private boolean sameDisplay(){DisplayMetrics d=metrics();return width==d.widthPixels&&height==d.heightPixels;}
    private void remove(View v){if(v!=null&&wm!=null)try{wm.removeViewImmediate(v);}catch(IllegalArgumentException ignored){}}
    void end(String reason){
        generation++;loop.removeCallbacksAndMessages(null);boolean was=game!=null;
        if(was){summary=reason+" Gestos: "+gestures+" · ajustes: "+adjustments;getSharedPreferences("live",0).edit().putString("last",summary)
            .putFloat(game+".gx",(float)gx).putFloat(game+".gy",(float)gy).apply();}
        closeNetworks();
        game=null;unavailableSince=0;pending=null;reading=false;tracking=false;entered=false;chosen=false;remove(picker);picker=null;remove(bar);bar=null;
    }
    private WindowManager.LayoutParams params(int w,int h){
        WindowManager.LayoutParams p=new WindowManager.LayoutParams(w,h,WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE|WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,PixelFormat.TRANSLUCENT);
        p.gravity=Gravity.TOP|Gravity.LEFT;return p;
    }
    private Button button(String s){Button b=new Button(this);b.setText(s);b.setTextSize(12);b.setAllCaps(false);return b;}
    private void showBar(){
        bar=new LinearLayout(this);bar.setGravity(Gravity.CENTER_VERTICAL);bar.setBackgroundColor(0xee101c33);
        info=new TextView(this);info.setTextColor(0xff51f5df);info.setText(" NEXUS ");info.setTextSize(12);bar.addView(info);
        calibrate=button("Calibrar");calibrate.setOnClickListener(v->beginPick());bar.addView(calibrate);
        if(mode!=0){
            if(mode==3){
                calibrate.setText("Ubicar botones");
                calibrate.setOnClickListener(v->{mapping=false;beginPick();});
                Button controls=button("HUD");controls.setOnClickListener(v->{mapping=true;beginPick();});bar.addView(controls);
            }else calibrate.setVisibility(View.GONE);
            if(mode==1){phaseKey=button(MatchBook.PHASES[phase]);phaseKey.setOnClickListener(v->{if(!reading&&!tracking){phase=(phase+1)%4;phaseKey.setText(MatchBook.PHASES[phase]);}});bar.addView(phaseKey);}
            runKey=button(mode==1?"Mostrar gesto":"Iniciar");runKey.setOnClickListener(v->beginMatch());
            if(mode==3)runKey.setOnLongClickListener(v->{
                if(!tracking && !reading){beginMatch();recordTarget=tracking;}
                return true;
            });
            bar.addView(runKey);
        }
        Button stop=button("Detener");stop.setOnClickListener(v->end("Detenida por el usuario."));bar.addView(stop);
        wm.addView(bar,params(-2,-2));
    }
    private void beginMatch(){
        if(!foreground())return;DisplayMetrics d=metrics();width=d.widthPixels;height=d.heightPixels;
        if(width<=height){info.setText(" Gira el teléfono ");return;}
        if(tracking||reading)return;
        if(mode==3 && ensemble==null){
            try{openNetworks();restoreUpdates();}
            catch(android.database.SQLException ex){closeNetworks();matchIdle("No se pudo abrir la memoria");return;}
        }
        reloadAfter=0;tactics=new Tactics();java.util.Arrays.fill(visits,0);explorationFrame=null;exploreStep=0;stalled=0;sightFrames=0;lootFrames=0;nextLoot=0;recordLoot=false;recordTarget=false;lootLocked=false;absentLoot=0;
        targetReference=android.util.Base64.decode(getSharedPreferences("hud-"+game,0).getString("targetSample",""),android.util.Base64.DEFAULT);
        String saved=getSharedPreferences("hud-"+game,0).getString("lootSample","");
        lootSample=android.util.Base64.decode(saved,android.util.Base64.DEFAULT);book.resetDecision();generation++;unknown=repeat=0;previous=null;tracking=true;runKey.setEnabled(false);
        info.setText(" Leyendo ");schedule(520);
    }
    private void matchIdle(String message){
        generation++;reading=false;pending=null;tracking=false;remove(picker);picker=null;bar.setVisibility(View.VISIBLE);runKey.setEnabled(true);info.setText(" "+message+" ");
    }
    private void example(byte[] f,float x,float y,float u,float v,int duration){
        try{book.add(phase,f,x,y,u,v,duration);}catch(RuntimeException ex){matchIdle("Perfil lleno o gesto inválido");return;}
        if(!persist()){book.examples.remove(book.examples.size()-1);matchIdle("Error al guardar");return;}
        matchIdle("Ejemplos: "+book.examples.size());
    }
    private void teach(byte[] features){
        if(phase==3){example(features,0,0,0,0,60);return;}
        if(book.examples.size()>=MatchBook.MAX){matchIdle("Perfil lleno");return;}
        pending=features;reading=true;picker=new FrameLayout(this);
        Button cancel=button("Cancelar ejemplo");cancel.setOnClickListener(v->matchIdle("Cancelado"));picker.addView(cancel,new FrameLayout.LayoutParams(-2,-2,Gravity.TOP|Gravity.RIGHT));
        picker.setOnTouchListener(new View.OnTouchListener(){
            float x,y;long down;
            public boolean onTouch(View view,MotionEvent e){
                if(!foreground()||!sameDisplay()){end("Ventana cambiada");return true;}
                if(e.getAction()==MotionEvent.ACTION_DOWN){x=e.getRawX()/width;y=e.getRawY()/height;down=e.getEventTime();}
                if(e.getAction()==MotionEvent.ACTION_UP){
                    float u=e.getRawX()/width,v=e.getRawY()/height;int ms=(int)clamp(e.getEventTime()-down,60,2000);byte[] features=pending;
                    remove(picker);picker=null;bar.setVisibility(View.VISIBLE);info.setText(" Aplicando ");
                    int id=generation;
                    loop.postDelayed(()->{if(valid(id))perform(id,x,y,u,v,ms,()->example(features,x,y,u,v,ms));},180);
                }
                if(e.getAction()==MotionEvent.ACTION_CANCEL&&picker!=null)matchIdle("Cancelado");
                return true;
            }
        });
        // Keep the original panel above the full-screen gesture picker.
        // Detener remains available while recording and while Android dispatches the gesture.
        try{
            wm.addView(picker,params(-1,-1));
            remove(bar);
            wm.addView(bar,params(-2,-2));
        }catch(RuntimeException error){end("No se pudo mostrar el panel de enseñanza.");}
    }
    private void perform(int id,float x,float y,float u,float v,int ms,Runnable completed){
        if(!valid(id))return;
        if(mode==1)loop.postDelayed(()->{
            if(game!=null && generation==id && tracking)matchIdle("Tiempo agotado · reintenta");
        },ms+3000L);
        GestureDescription.Builder b=new GestureDescription.Builder();stroke(b,x,y,u,v,ms);
        dispatchPrepared(id,b,completed);
    }
    private void dispatchPrepared(int id,GestureDescription.Builder b,Runnable completed){
        if(!valid(id))return;
        boolean ok=dispatchGesture(b.build(),new GestureResultCallback(){
            public void onCompleted(GestureDescription g){if(valid(id)){gestures++;completed.run();}}
            public void onCancelled(GestureDescription g){if(valid(id))matchIdle("Gesto cancelado");}
        },loop);
        if(!ok)matchIdle("Gesto rechazado");
    }
    private MovementNet[] ensemble;
    private int learned;
    private void openNetworks(){
        ensemble=new MovementNet[64];
        for(int i=0;i<ensemble.length;i++)ensemble[i]=new MovementNet(117+7919*i);
        android.content.SharedPreferences prefs=getSharedPreferences("net-v2-"+game,0);
        learned=prefs.getInt("steps",0);
        for(int i=0;i<ensemble.length;i++){
            String data=prefs.getString("model"+i,"");
            try{ensemble[i].load(android.util.Base64.decode(data,android.util.Base64.DEFAULT));}
            catch(IllegalArgumentException ignored){}
        }
    }
    private android.database.sqlite.SQLiteDatabase checkpoints;
    private void closeNetworks(){
        if(checkpoints!=null){checkpoints.close();checkpoints=null;}
        ensemble=null;
    }
    private void restoreUpdates(){
        checkpoints=openOrCreateDatabase("explore-updates-"+game+".db",MODE_PRIVATE,null);
        checkpoints.enableWriteAheadLogging();
        checkpoints.execSQL("CREATE TABLE IF NOT EXISTS experts(id INTEGER PRIMARY KEY, step INTEGER NOT NULL, weights BLOB NOT NULL)");
        try(android.database.Cursor rows=checkpoints.rawQuery("SELECT id,step,weights FROM experts",null)){
            while(rows.moveToNext()){
                int id=rows.getInt(0);
                if(id>=0 && id<ensemble.length){
                    ensemble[id].load(rows.getBlob(2));
                    learned=Math.max(learned,rows.getInt(1));
                }
            }
        }
    }
    private void trainAndSave(float target){
        // Commit just the four changed experts as one revision before picking the next action.
        int revision=learned+1;
        checkpoints.beginTransaction();
        try{
            for(int k=0;k<4;k++){
                int id=(learned*4+k)&63;
                ensemble[id].train(explorationFrame,lastMove,target);
                checkpoints.execSQL("INSERT OR REPLACE INTO experts VALUES(?,?,?)",
                    new Object[]{id,revision,ensemble[id].save()});
            }
            checkpoints.setTransactionSuccessful();
        }finally{checkpoints.endTransaction();}
        learned=revision;
    }
    private byte[] explorationFrame;
    private int lastMove, exploreStep, stalled, sightFrames, lootFrames;
    private long nextLoot;
    private boolean recordLoot, recordTarget, lootLocked;
    private int absentLoot;
    private byte[] targetReference;
    private byte[] lootSample;
    private void useControl(int id,boolean loot){
        android.content.SharedPreferences hud=getSharedPreferences("hud-"+game,0);
        float x=hud.getFloat(loot?"lootX":"fireX",loot?.83f:.89f);
        float y=hud.getFloat(loot?"lootY":"fireY",loot?.43f:.72f);
        info.setText(loot?" Recoger ":" Disparar · diana confirmada ");
        explorationFrame=null;
        perform(id,x,y,x,y,loot?90:320,()->schedule(680));
    }
    // Normalized controls for a landscape screen with the default joystick.
    private static final float[][] MOVES = {
        {.15f,.77f,.15f,.62f}, {.15f,.77f,.05f,.74f}, {.15f,.77f,.25f,.74f},
        {.67f,.48f,.54f,.48f}, {.67f,.48f,.80f,.48f}, {.67f,.48f,.67f,.41f},
        {0,0,0,.14f},{0,0,0,.10f},{0,0,-.09f,-.12f},{0,0,.09f,-.12f},
        {0,0,0,-.15f},{0,0,0,-.15f}
    };
    private static final String[] NAMES = {"Avanzar","Izquierda","Derecha","Girar izq.","Girar der.","Subir vista","Retroceder","Bajar vista","Diagonal izq.","Diagonal der.","Avanzar y girar izq.","Avanzar y girar der.","Saltar","Agacharse","Recargar"};
    private final java.util.Random random = new java.util.Random();
    private void explore(int id, byte[] scene) {
        android.content.SharedPreferences memory = getSharedPreferences("explorar-"+game,0);
        android.content.SharedPreferences hud=getSharedPreferences("hud-"+game,0);
        byte[] local=VisualCues.patch(rgb,hud.getFloat("lootX",.83f),hud.getFloat("lootY",.43f));
        if(recordTarget){
            recordTarget=false;
            byte[] candidate=VisualCues.targetPatch(rgb);
            if(!VisualCues.confirmedTarget(rgb,candidate)){
                matchIdle("Centra una diana con detalle y mira roja");return;
            }
            hud.edit().putString("targetSample",android.util.Base64.encodeToString(candidate,android.util.Base64.NO_WRAP)).apply();
            matchIdle("Diana registrada");return;
        }
        if(recordLoot){
            recordLoot=false;
            if(!VisualCues.matches(local,local)){matchIdle("Botín sin detalle · ubicar de nuevo");return;}
            hud.edit().putString("lootSample",android.util.Base64.encodeToString(local,android.util.Base64.NO_WRAP)).apply();
            matchIdle("Botín registrado");return;
        }
        if (explorationFrame != null) {
            int change = 0;
            for (int i=0; i<scene.length; i++)
                change += Math.abs((scene[i]&255)-(explorationFrame[i]&255));
            float response = Math.min(1f, change / (scene.length * 36f));
            stalled=lastMove==0 && response<.12f ? stalled+1 : 0;
            boolean cameraOnly=lastMove==3 || lastMove==4 || lastMove==5 || lastMove==7;
            float target=cameraOnly?Math.min(.05f,response)-.15f:response*2-1;
            try{trainAndSave(target);}
            catch(android.database.SQLException ex){
                closeNetworks();explorationFrame=null;matchIdle("No se pudo guardar · en pausa");return;
            }
            float prior = memory.getFloat(NAMES[lastMove], .5f);
            memory.edit().putFloat(NAMES[lastMove], prior + .15f*(response-prior)).apply();
        }
        long now=SystemClock.elapsedRealtime();
        boolean visibleLoot=VisualCues.matches(lootSample,local);
        absentLoot=visibleLoot?0:Math.min(2,absentLoot+1);
        if(absentLoot>=2)lootLocked=false;
        boolean loot=!lootLocked && now>=nextLoot && visibleLoot;
        GameText labels=readGameText();
        if(labels.finished){end("Fin de partida indicado por el juego.");return;}
        boolean sight=!labels.emptyMagazine && !labels.noReserve && VisualCues.confirmedTarget(rgb,targetReference);
        lootFrames=loot?lootFrames+1:0;
        sightFrames=sight?sightFrames+1:0;
        float hp=Tactics.health(rgb,Tracker.W,Tracker.H,hud.getFloat("extraX7",-1),
            hud.getFloat("extraX8",-1),hud.getFloat("extraY7",-1));
        Tactics.Intent intent=tactics.decide(now,hp,sightFrames>=2,hud.contains("extraX5") && !labels.noKit,hud.contains("extraX6"));
        if(intent!=Tactics.Intent.WATCH){
            explorationFrame=null;
            if(intent==Tactics.Intent.WAIT){info.setText(" Esperando curación ");schedule(600);return;}
            if(intent==Tactics.Intent.FIRE){sightFrames=0;useControl(id,false);return;}
            boolean heal=intent==Tactics.Intent.HEAL;
            int key=heal?5:6;
            float x=hud.getFloat("extraX"+key,0),y=hud.getFloat("extraY"+key,0);
            info.setText(heal?" Curar · vida baja ":" Correr · perdiendo vida ");
            perform(id,x,y,x,y,110,()->schedule(620));return;
        }
        if(labels.emptyMagazine && !labels.noReserve && hud.contains("extraX2") && now>=reloadAfter){
            reloadAfter=now+4500;explorationFrame=null;
            float x=hud.getFloat("extraX2",0),y=hud.getFloat("extraY2",0);
            info.setText(" Recargar · cargador vacío ");
            perform(id,x,y,x,y,90,()->schedule(650));return;
        }
        if(lootFrames>=2){
            lootLocked=true;nextLoot=now+2500;lootFrames=0;useControl(id,true);return;
        }
        if(loot || sight){
            explorationFrame=null;info.setText(" Confirmando ");schedule(550);return;
        }
        exploreStep++;
        float[] scores=new float[NAMES.length];
        for(MovementNet expert:ensemble){
            float[] prediction=expert.predict(scene);
            for(int i=0;i<scores.length;i++)scores[i]+=prediction[i]/ensemble.length;
        }
        double best = Double.NEGATIVE_INFINITY;
        int choice = 0;
        for (int i=0; i<NAMES.length; i++) {
            if(i>=12 && !hud.contains("extraX"+(i-12)))continue;
            double score=scores[i]
                +.25*memory.getFloat(NAMES[i],.5f)+random.nextDouble()*.24;
            score+=.45/Math.sqrt(1+visits[i]);
            if(explorationFrame!=null && (i==lastMove || opposite(i,lastMove)))score-=.85;
            if(i==14)continue; // Reload requires ammo information; keep it out of blind exploration.
            if (score>best) { best=score; choice=i; }
        }
        visits[choice]++;
        if(stalled>=2){choice=random.nextBoolean()?3:4;stalled=0;}
        lastMove=choice;
        explorationFrame=scene;
        float sx=hud.getFloat("extraX3",.15f), sy=hud.getFloat("extraY3",.77f);
        float cx=hud.getFloat("extraX4",.67f), cy=hud.getFloat("extraY4",.48f);
        info.setText(" "+NAMES[choice]+" · v"+learned+" ");
        GestureDescription.Builder gesture=new GestureDescription.Builder();
        if(choice>=12){
            float x=hud.getFloat("extraX"+(choice-12),0), y=hud.getFloat("extraY"+(choice-12),0);
            stroke(gesture,x,y,x,y,85);
        }else{
            boolean walking=choice<=2 || choice==6 || choice==8 || choice==9 || choice>=10;
            float[] g=MOVES[choice];
            float x=walking?sx:cx,y=walking?sy:cy;
            stroke(gesture,x,y,clamp(x+g[2]-g[0],.01,.99),clamp(y+g[3]-g[1],.01,.99),walking?780:240);
            if(choice>=10)stroke(gesture,cx,cy,clamp(cx+(choice==10?-.12:.12),.01,.99),cy,300);
        }
        dispatchPrepared(id,gesture,()->schedule(650));
    }
    private void match(int id){
        if(mode==3){
            byte[] frame=new byte[144];
            for(int y=0;y<9;y++)for(int x=0;x<16;x++){
                int sum=0;
                for(int j=0;j<4;j++)for(int i=0;i<4;i++){
                    int c=rgb[((8*y+2*j+1)*Tracker.H/72)*Tracker.W+(8*x+2*i+1)*Tracker.W/128];
                    sum+=((c>>16&255)*3+(c>>8&255)*6+(c&255))/10;
                }
                frame[y*16+x]=(byte)(sum/16);
            }
            explore(id,frame);return;
        }
        byte[] f=MatchBook.describe(rgb,Tracker.W,Tracker.H);
        if(mode==1){teach(f);return;}
        MatchBook.Example e=book.choose(phase,f);
        if(e==null){info.setText(" Buscando fase ");if(++unknown>90){matchIdle("Escena desconocida");return;}schedule(1000);return;}
        phase=e.phase;unknown=0;
        if(phase==3){end("Pantalla de resultados reconocida.");return;}
        if(e==previous){if(++repeat>12){matchIdle("Escena repetida");return;}}else{repeat=0;previous=e;}
        info.setText(" "+MatchBook.PHASES[phase]+" ");
        perform(id,e.x,e.y,e.u,e.v,e.millis,()->schedule(850));
    }
    private int textBudget;
    private long reloadAfter;
    private GameText readGameText(){
        GameText signals=new GameText();
        textBudget=96;
        for(AccessibilityWindowInfo w:getWindows()){
            if(w.getType()!=AccessibilityWindowInfo.TYPE_APPLICATION)continue;
            AccessibilityNodeInfo node=w.getRoot();
            if(node!=null){
                try{if(game.contentEquals(String.valueOf(node.getPackageName())))readLabels(node,signals,0);}
                finally{node.recycle();}
            }
            break;
        }
        return signals;
    }
    private void readLabels(AccessibilityNodeInfo node,GameText signals,int depth){
        if(--textBudget<0 || depth>14 || node.isPassword())return;
        if(node.isVisibleToUser()){
            signals.read(node.getText());signals.read(node.getContentDescription());
        }
        for(int i=0;i<node.getChildCount() && textBudget>0;i++){
            AccessibilityNodeInfo child=node.getChild(i);
            if(child!=null){try{readLabels(child,signals,depth+1);}finally{child.recycle();}}
        }
    }
    private Tactics tactics;
    private final int[] visits=new int[15];
    private boolean opposite(int a,int b){
        return (a==1&&b==2)||(a==2&&b==1)||(a==3&&b==4)||(a==4&&b==3)
            ||(a==5&&b==7)||(a==7&&b==5)||(a==0&&b==6)||(a==6&&b==0);
    }
    private boolean mapping;
    private final String[] anchors={"Saltar","Agacharse","Recargar","centro del joystick","zona libre de cámara","botiquín","correr","extremo izquierdo de la barra de vida llena","extremo derecho de la misma barra"};
    private String prompt(){
        if(mode==3 && mapping)return "Toca "+anchors[step];
        if(mode==3)return step==0?"Toca el botón Disparar":"Toca la primera fila de botín visible";
        if(step==0)return "Toca una zona libre donde arrastrar la cámara";
        if(step==1)return "Toca el centro del joystick";
        if(step==2)return "Toca el botón de acción que quieres pulsar";
        return "Toca un detalle contrastado de la diana";
    }
    private void beginPick(){
        if(!foreground()){end("El juego no está activo.");return;}
        DisplayMetrics d=metrics();width=d.widthPixels;height=d.heightPixels;
        if(width<=height){info.setText(" Gira a horizontal ");return;}
        generation++;tracking=false;chosen=false;cmdX=cmdY=0;step=0;
        bar.setVisibility(View.GONE);picker=new FrameLayout(this);LinearLayout guide=new LinearLayout(this);
        guide.setBackgroundColor(0xee101c33);TextView label=new TextView(this);label.setTextColor(-1);label.setText(prompt());guide.addView(label);
        Button stop=button("Detener");stop.setOnClickListener(v->end("Detenida durante calibración."));guide.addView(stop);
        picker.addView(guide,new FrameLayout.LayoutParams(-2,-2,Gravity.TOP|Gravity.CENTER_HORIZONTAL));
        picker.setOnTouchListener((v,e)->{
            if(e.getAction()!=MotionEvent.ACTION_UP)return true;
            if(!foreground()||!sameDisplay()){end("Cambió la ventana durante la calibración.");return true;}
            if(mode==3){
                android.content.SharedPreferences.Editor edit=getSharedPreferences("hud-"+game,0).edit();
                float x=e.getRawX()/width, y=e.getRawY()/height;
                if(mapping){
                    edit.putFloat("extraX"+step,x).putFloat("extraY"+step,y).apply();
                    if(++step<anchors.length){label.setText(prompt());return true;}
                    mapping=false;matchIdle("HUD guardado");return true;
                }
                if(step==0){fire[0]=x;fire[1]=y;step++;label.setText(prompt());return true;}
                edit.putFloat("fireX",fire[0]).putFloat("fireY",fire[1])
                    .putFloat("lootX",x).putFloat("lootY",y).apply();
                remove(picker);picker=null;bar.setVisibility(View.VISIBLE);
                recordLoot=true;tracking=true;runKey.setEnabled(false);
                info.setText(" Leyendo botín ");schedule(600);return true;
            }
            float[] point=step==0?camera:step==1?stick:step==2?fire:mark;
            point[0]=e.getRawX()/width;point[1]=e.getRawY()/height;
            if(point[0]<.02||point[0]>.98||point[1]<.03||point[1]>.97){label.setText("Elige un punto dentro del campo");return true;}
            if(step<3){step++;if(step==1&&!move)step++;if(step==2&&!tap)step++;label.setText(prompt());return true;}
            remove(picker);picker=null;bar.setVisibility(View.VISIBLE);chosen=false;tracking=true;calibrate.setEnabled(false);
            info.setText(" Lectura… ");schedule(450);return true;
        });
        wm.addView(picker,params(-1,-1));
    }
    private void pauseTrack(String why){
        if(mode!=0){matchIdle(why);return;}
        generation++;tracking=false;cmdX=cmdY=0;calibrate.setEnabled(true);info.setText(" "+why+" ");
    }
    private boolean valid(int id){
        if(game==null||generation!=id||!tracking)return false;
        if(!foreground()){
            if(mode==1){checkWindow();return false;}
            end("Sesión finalizada.");return false;
        }
        if(!sameDisplay()||SystemClock.elapsedRealtime()>deadline){end("Sesión finalizada.");return false;}
        return true;
    }
    private void schedule(long ms){final int id=generation;loop.postDelayed(()->{if(valid(id))capture(id);},ms);}
    private void capture(int id){
        try{takeScreenshot(Display.DEFAULT_DISPLAY,getMainExecutor(),new TakeScreenshotCallback(){
            public void onSuccess(ScreenshotResult r){
                HardwareBuffer buffer=r.getHardwareBuffer();Bitmap hw=null,small=null,soft=null;
                try{
                    if(!valid(id))return;
                    hw=Bitmap.wrapHardwareBuffer(buffer,r.getColorSpace());
                    if(hw==null||hw.getWidth()!=width||hw.getHeight()!=height){pauseTrack("Imagen incompatible");return;}
                    small=Bitmap.createScaledBitmap(hw,Tracker.W,Tracker.H,true);soft=small.copy(Bitmap.Config.ARGB_8888,false);
                    soft.getPixels(rgb,0,Tracker.W,0,0,Tracker.W,Tracker.H);
                }catch(RuntimeException|OutOfMemoryError ex){if(valid(id))pauseTrack("Imagen no disponible");return;}
                finally{if(soft!=null)soft.recycle();if(small!=null&&small!=hw)small.recycle();if(hw!=null)hw.recycle();buffer.close();}
                if(valid(id)){if(mode==0)observe(id);else match(id);}
            }
            public void onFailure(int error){if(valid(id))pauseTrack("Captura bloqueada ("+error+")");}
        });}catch(RuntimeException e){if(valid(id))pauseTrack("Sin permiso de captura");}
    }
    private void observe(int id){
        if(!chosen){
            chosen=tracker.select(rgb,(int)(mark[0]*Tracker.W),(int)(mark[1]*Tracker.H));
            if(!chosen){pauseTrack("Detalle insuficiente");return;}
        }
        int[] p=tracker.locate(rgb);
        if(p==null){pauseTrack("Referencia perdida");return;}
        double x=p[0]/(double)Tracker.W-.5,y=p[1]/(double)Tracker.H-.5;
        double nx=Tracker.adapt(gx,prevX,x,cmdX),ny=Tracker.adapt(gy,prevY,y,cmdY);
        if(nx!=gx||ny!=gy){gx=nx;gy=ny;adjustments++;}
        prevX=x;prevY=y;boolean centered=Math.abs(x)<.035&&Math.abs(y)<.045;
        cmdX=centered?0:clamp(x*.45/gx,-.07,.07);cmdY=centered?0:clamp(y*.45/gy,-.09,.09);
        GestureDescription.Builder b=new GestureDescription.Builder();int strokes=0;
        if(!centered){double ex=clamp(camera[0]+cmdX,.02,.98),ey=clamp(camera[1]+cmdY,.04,.96);
            cmdX=ex-camera[0];cmdY=ey-camera[1];stroke(b,camera[0],camera[1],ex,ey,140);strokes++;}
        if(move&&Math.abs(x)<.10){stroke(b,stick[0],stick[1],stick[0],Math.max(.04,stick[1]-.08),230);strokes++;}
        long now=SystemClock.elapsedRealtime();
        if(tap&&centered&&now>=nextTap){stroke(b,fire[0],fire[1],fire[0],fire[1],60);nextTap=now+1000;strokes++;}
        info.setText(" NEXUS · "+gestures+" ");
        if(strokes==0){schedule(520);return;}
        if(!valid(id))return;
        boolean sent=dispatchGesture(b.build(),new GestureResultCallback(){
            public void onCompleted(GestureDescription g){if(valid(id)){gestures++;schedule(520);}}
            public void onCancelled(GestureDescription g){if(valid(id))pauseTrack("Gesto cancelado");}
        },loop);
        if(!sent)pauseTrack("Gesto rechazado");
    }
    private static double clamp(double x,double a,double b){return Math.max(a,Math.min(b,x));}
    private void stroke(GestureDescription.Builder b,double x,double y,double ex,double ey,long time){
        Path path=new Path();path.moveTo((float)(width*x),(float)(height*y));
        if(x!=ex||y!=ey)path.lineTo((float)(width*ex),(float)(height*ey));
        b.addStroke(new GestureDescription.StrokeDescription(path,0,time));
    }
}
