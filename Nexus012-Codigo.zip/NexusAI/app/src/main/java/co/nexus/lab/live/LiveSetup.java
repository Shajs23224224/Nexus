package co.nexus.lab.live;

import android.app.Activity;
import android.content.*;
import android.os.*;
import android.provider.Settings;
import android.widget.*;

public final class LiveSetup extends Activity {
    private TextView state;
    private Switch movement,action;
    private Spinner games,mode;
    private Button launch;
    private String message="";
    private void status(){
        boolean available=Build.VERSION.SDK_INT>=30 && LiveService.connected!=null;
        state.setText((available?"Servicio conectado.":"Activa el servicio NEXUS en Accesibilidad y vuelve aquí.")+" "+message);
        launch.setEnabled(available);
    }
    @Override public void onCreate(Bundle b){
        super.onCreate(b);ScrollView scroll=new ScrollView(this);LinearLayout col=new LinearLayout(this);
        col.setOrientation(1);int p=Math.round(16*getResources().getDisplayMetrics().density);col.setPadding(p,p,p,p);
        col.setBackgroundColor(0xff081226);scroll.addView(col);setContentView(scroll);
        TextView title=new TextView(this);title.setTextSize(25);title.setText("Controles en el juego");col.addView(title);
        TextView intro=new TextView(this);intro.setText("Entrenamiento con una referencia visual. Entra al campo de prueba, pulsa Calibrar y toca los controles que indica la pantalla. Elige un detalle contrastado de la diana. NEXUS intenta llevarlo al centro y ajusta la sensibilidad según el movimiento observado.");col.addView(intro);
        games=new Spinner(this);games.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{"Free Fire","Free Fire MAX"}));col.addView(games);
        mode=new Spinner(this);mode.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{"Seguimiento de diana","Enseñar una partida","Ejecutar una partida aprendida","Explorar sin ejemplos"}));col.addView(mode);
        TextView guide=new TextView(this);guide.setText("En Explorar sin ejemplos, entra al campo de entrenamiento con el joystick estándar y pulsa Iniciar. Usa Ubicar botones una vez junto al botín visible. NEXUS busca esa fila y una diana registrada. Apunta a la diana con la mira roja y mantén pulsado Iniciar para registrarla. Para una partida aprendida, enseña ejemplos desde el lobby hasta resultados. Selecciona la fase y pulsa Mostrar gesto antes de demostrar una acción. En Resultados se registra la pantalla final. Ejecutar usa el perfil local de esa edición.");col.addView(guide);
        movement=new Switch(this);movement.setText("Avanzar con el joystick durante el seguimiento");col.addView(movement);
        action=new Switch(this);action.setText("Pulsar el control de acción al centrar la referencia");col.addView(action);
        TextView data=new TextView(this);data.setText("Requiere Android 11 o posterior. Captura imágenes de pantalla de forma temporal mientras la sesión está activa. Solo persiste la sensibilidad estimada. Usa Detener para finalizar.");col.addView(data);
        Button settings=new Button(this);settings.setText("Configurar Accesibilidad");col.addView(settings);
        settings.setOnClickListener(v->startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        launch=new Button(this);launch.setText("Abrir juego y preparar sesión");col.addView(launch);
        state=new TextView(this);col.addView(state);launch.setOnClickListener(v->{
            String pkg=games.getSelectedItemPosition()==1?"com.dts.freefiremax":"com.dts.freefireth";
            Intent i=getPackageManager().getLaunchIntentForPackage(pkg);LiveService svc=LiveService.connected;
            if(i==null||svc==null){message=i==null?"No se encontró la edición seleccionada.":"Servicio desconectado.";status();return;}
            if(!svc.prepare(pkg,movement.isChecked(),action.isChecked(),mode.getSelectedItemPosition())){message="Faltan ejemplos de las cuatro fases o el perfil no se pudo leer.";status();return;}
            try{startActivity(i);}catch(ActivityNotFoundException|SecurityException e){svc.end("No se pudo abrir el juego.");message="No se pudo abrir el juego.";status();}
        });
    }
    @Override protected void onResume(){super.onResume();message=getSharedPreferences("live",0).getString("last","");status();}
}
