package co.nexus.lab.live;

import java.util.Random;
import java.nio.ByteBuffer;

final class MovementNet {
    private static final int[] WIDTH={144,12,12,12,12,12,12,12,12,12,12,12,12,15};
    private final float[][] weights=new float[WIDTH.length-1][];
    private final float[][] values=new float[WIDTH.length][];
    private final float[][] gradients=new float[WIDTH.length][];

    MovementNet(int seed){
        Random rng=new Random(seed);
        for(int l=0;l<WIDTH.length;l++){
            values[l]=new float[WIDTH[l]];
            gradients[l]=new float[WIDTH[l]];
            if(l==0)continue;
            weights[l-1]=new float[(WIDTH[l-1]+1)*WIDTH[l]];
            for(int i=0;i<weights[l-1].length;i++)
                weights[l-1][i]=(float)(rng.nextGaussian()/Math.sqrt(WIDTH[l-1]));
        }
    }
    float[] predict(byte[] frame){
        for(int i=0;i<frame.length;i++)values[0][i]=(frame[i]&255)/127.5f-1f;
        for(int l=0;l<weights.length;l++){
            int inputs=WIDTH[l];
            for(int j=0;j<WIDTH[l+1];j++){
                int offset=j*(inputs+1);
                float sum=weights[l][offset+inputs];
                for(int i=0;i<inputs;i++)sum+=weights[l][offset+i]*values[l][i];
                values[l+1][j]=(float)Math.tanh(sum);
            }
        }
        return values[weights.length];
    }
    void train(byte[] frame,int action,float target){
        predict(frame);
        java.util.Arrays.fill(gradients[weights.length],0f);
        gradients[weights.length][action]=target-values[weights.length][action];
        for(int l=weights.length-1;l>=0;l--){
            int inputs=WIDTH[l];
            java.util.Arrays.fill(gradients[l],0f);
            for(int j=0;j<WIDTH[l+1];j++){
                float output=values[l+1][j];
                float delta=gradients[l+1][j]*(1-output*output);
                int offset=j*(inputs+1);
                for(int i=0;i<inputs;i++){
                    gradients[l][i]+=delta*weights[l][offset+i];
                    weights[l][offset+i]+=.004f*delta*values[l][i];
                }
                weights[l][offset+inputs]+=.004f*delta;
            }
        }
    }
    byte[] save(){
        int count=0;
        for(float[] layer:weights)count+=layer.length;
        ByteBuffer data=ByteBuffer.allocate(count*4);
        for(float[] layer:weights)for(float w:layer)data.putFloat(w);
        return data.array();
    }
    void load(byte[] bytes){
        int count=0;
        for(float[] layer:weights)count+=layer.length;
        if(bytes.length!=count*4)return;
        ByteBuffer data=ByteBuffer.wrap(bytes);
        for(float[] layer:weights)for(int i=0;i<layer.length;i++)layer[i]=data.getFloat();
    }
}
