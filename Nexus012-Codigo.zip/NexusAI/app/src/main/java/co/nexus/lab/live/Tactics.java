package co.nexus.lab.live;

final class Tactics {
    enum Intent { WATCH, HEAL, WAIT, RUN, FIRE }
    private float previous=-1;
    private int lowFrames;
    private long dangerUntil, healingUntil, nextHeal, nextRun;
    Intent decide(long now,float hp,boolean aiming,boolean hasHeal,boolean hasSprint){
        if(hp>=0 && previous>=0 && previous-hp>.055f)dangerUntil=now+3500;
        previous=hp;
        lowFrames=hp>=0 && hp<.58f?lowFrames+1:0;
        if(now<dangerUntil && hp>=0 && hp<.70f && hasSprint && now>=nextRun){
            healingUntil=0;nextRun=now+2400;return Intent.RUN;
        }
        if(aiming){healingUntil=0;return Intent.FIRE;}
        if(now<healingUntil)return Intent.WAIT;
        if(lowFrames>=2 && now>=dangerUntil && now>=nextHeal && hasHeal){
            healingUntil=now+4200;nextHeal=now+12000;return Intent.HEAL;
        }
        return Intent.WATCH;
    }
    // Fraction of a horizontal HUD bar with a continuous bright or green fill.
    static float health(int[] rgb,int width,int height,float left,float right,float y){
        int start=Math.round(left*(width-1)), end=Math.round(right*(width-1));
        int row=Math.round(y*(height-1));
        if(start<0 || end>=width || end-start<10 || row<0 || row>=height)return -1;
        int gap=0,last=start-1;
        for(int x=start;x<=end;x++){
            int c=rgb[row*width+x],r=c>>16&255,g=c>>8&255,b=c&255;
            if((Math.min(r,Math.min(g,b))>155 || (g>120 && g>r*1.25 && g>b*1.2))){
                last=x;gap=0;
            }else if(++gap>=2)break;
        }
        return last<start+1?-1:(last-start+1f)/(end-start+1f);
    }
}
