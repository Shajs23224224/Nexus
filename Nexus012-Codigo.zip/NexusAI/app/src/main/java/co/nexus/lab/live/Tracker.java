package co.nexus.lab.live;

/** Local template matching on a reduced RGB frame. No network or retained screenshots. */
public final class Tracker {
    public static final int W=224,H=112;
    private static final int R=4,S=2,N=81;
    private final int[] template=new int[N];
    private int lastX,lastY;

    public boolean select(int[] rgb,int x,int y){
        if(x<10||x>=W-10||y<10||y>=H-10)return false;
        long sum=0,square=0;int i=0;
        for(int dy=-R;dy<=R;dy++)for(int dx=-R;dx<=R;dx++){
            int c=rgb[(y+dy*S)*W+x+dx*S];template[i++]=c;
            int l=((c>>16&255)*3+(c>>8&255)*6+(c&255))/10;
            sum+=l;square+=(long)l*l;
        }
        lastX=x;lastY=y;
        return square/(double)N-Math.pow(sum/(double)N,2)>48;
    }
    private int distance(int[] frame,int x,int y){
        int sum=0,i=0;
        for(int dy=-R;dy<=R;dy++)for(int dx=-R;dx<=R;dx++){
            int a=frame[(y+dy*S)*W+x+dx*S],b=template[i++];
            sum+=Math.abs((a>>16&255)-(b>>16&255))+Math.abs((a>>8&255)-(b>>8&255))+Math.abs((a&255)-(b&255));
        }
        return sum;
    }
    public int[] locate(int[] rgb){
        int best=Integer.MAX_VALUE,bx=0,by=0;
        int x0=Math.max(9,lastX-30),x1=Math.min(W-10,lastX+30);
        int y0=Math.max(9,lastY-24),y1=Math.min(H-10,lastY+24);
        for(int y=y0;y<=y1;y+=2)for(int x=x0;x<=x1;x+=2){
            int d=distance(rgb,x,y);if(d<best){best=d;bx=x;by=y;}
        }
        if(best>3*N*34)return null;
        int baseX=bx,baseY=by;
        for(int y=Math.max(9,baseY-1);y<=Math.min(H-10,baseY+1);y++)for(int x=Math.max(9,baseX-1);x<=Math.min(W-10,baseX+1);x++){
            int d=distance(rgb,x,y);if(d<best){best=d;bx=x;by=y;}
        }
        int alternative=Integer.MAX_VALUE;
        for(int y=y0;y<=y1;y+=3)for(int x=x0;x<=x1;x+=3){
            if(Math.abs(x-bx)<8 && Math.abs(y-by)<8)continue;
            alternative=Math.min(alternative,distance(rgb,x,y));
        }
        if(alternative<best+N*9)return null;
        lastX=bx;lastY=by;return new int[]{bx,by};
    }
    public static double adapt(double gain,double prev,double current,double swipe){
        if(Math.abs(swipe)<.008)return gain;
        double observed=(prev-current)/swipe;
        return observed>.12&&observed<8?gain*.85+observed*.15:gain;
    }
}
