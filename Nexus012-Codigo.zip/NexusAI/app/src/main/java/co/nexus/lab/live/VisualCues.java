package co.nexus.lab.live;

final class VisualCues {
    // A compact grayscale sample of the selected loot row. Offsets are clamped for custom HUDs.
    static byte[] patch(int[] frame,float x,float y){
        byte[] sample=new byte[91];
        int k=0;
        for(int row=-3;row<=3;row++)for(int col=-6;col<=6;col++){
            int px=Math.max(0,Math.min(Tracker.W-1,Math.round(x*(Tracker.W-1))+col));
            int py=Math.max(0,Math.min(Tracker.H-1,Math.round(y*(Tracker.H-1))+row));
            int c=frame[py*Tracker.W+px];
            sample[k++]=(byte)(((c>>16&255)*3+(c>>8&255)*6+(c&255))/10);
        }
        return sample;
    }
    static boolean matches(byte[] ref,byte[] view){
        if(ref==null || ref.length!=view.length)return false;
        double a=0,b=0,aa=0,bb=0,ab=0;
        for(int i=0;i<ref.length;i++){
            int x=ref[i]&255,y=view[i]&255;
            a+=x;b+=y;aa+=x*x;bb+=y*y;ab+=x*y;
        }
        int n=ref.length;
        double va=aa-a*a/n,vb=bb-b*b/n;
        return va>n*36 && vb>n*36 && ab-a*b/n>.78*Math.sqrt(va*vb);
    }
    // Sample the appearance around the reticle, excluding the reticle itself.
    static byte[] targetPatch(int[] frame){
        byte[] patch=new byte[17*11-9];
        int index=0;
        for(int row=-8;row<=8;row++)for(int col=-5;col<=5;col++){
            if(Math.abs(row)<=1 && Math.abs(col)<=1)continue;
            int c=frame[(Tracker.H/2+row*3)*Tracker.W+Tracker.W/2+col*3];
            patch[index++]=(byte)(((c>>16&255)*3+(c>>8&255)*6+(c&255))/10);
        }
        return patch;
    }
    static boolean confirmedTarget(int[] frame,byte[] reference){
        return reference!=null && redSight(frame) && matches(reference,targetPatch(frame));
    }
    static boolean redSight(int[] frame){
        int red=0;
        for(int dy=-3;dy<=3;dy++)for(int dx=-3;dx<=3;dx++){
            int c=frame[(Tracker.H/2+dy)*Tracker.W+Tracker.W/2+dx];
            int r=c>>16&255,g=c>>8&255,b=c&255;
            if(r>125 && r>g*1.55 && r>b*1.5)red++;
        }
        return red>=3 && red<=30;
    }
}
