# NEXUS AI 0.4 · Controles visuales en el juego

## Instalación y activación

1. Extrae el ZIP y abre NEXUS-AI-0.4.apk. La firma y el identificador permiten actualizar la versión 0.3 distribuida previamente.
2. En NEXUS, abre **Prueba de controles en Free Fire**. Selecciona la edición instalada. Puedes habilitar por separado el uso del joystick y del botón de acción. Ambos empiezan desactivados.
3. Pulsa **Configurar Accesibilidad**, busca **NEXUS · Prueba de controles** entre los servicios instalados, habilítalo y vuelve a la aplicación. Android 11 o posterior es necesario para la captura de esta versión.
4. Pulsa **Abrir juego y preparar sesión**. Una vez en el campo de entrenamiento, coloca la pantalla en horizontal y pulsa **Calibrar** en el panel NEXUS. Puedes entrar manualmente en el campo con el panel visible.
5. Toca una zona libre que permita arrastrar la cámara. Si elegiste avance, toca el centro del joystick. Si elegiste acción, toca la ubicación del botón que corresponde a esa acción en tu HUD. Finalmente, toca una zona con textura de la diana que quieras seguir. Escoge un punto identificable y separado de los botones del HUD.
6. El servicio busca la referencia en imágenes posteriores, corrige la cámara para centrarla y estima la respuesta observada al arrastre. Cuando se pierde la referencia, el panel permite recalibrar. **Detener** termina la sesión. Volver a NEXUS permite ver el motivo de cierre, cuántos gestos finalizaron y cuántos ajustes de sensibilidad se hicieron.

## Qué controla

El seguidor utiliza una plantilla RGB de 81 muestras y busca en una vecindad temporal de la posición anterior. Rechaza selecciones con textura insuficiente y coincidencias ambiguas. Envía un arrastre acotado para la cámara. Si se habilitó el joystick, añade un gesto de avance cuando el error horizontal es pequeño. Si se habilitó el control de acción, puede pulsarlo como máximo una vez por segundo mientras la referencia esté centrada. Son posiciones elegidas por el usuario. Un cambio de HUD requiere repetir la calibración. El seguidor puede confundir elementos parecidos o perder la referencia ante cambios de escala, iluminación o perspectiva.

La sensibilidad horizontal y vertical se ajusta a partir del movimiento visual posterior al gesto y se guarda por edición al terminar la sesión. También pueden influir los movimientos del objetivo. El contador de gestos confirmados registra finalizaciones informadas por Android. Solo observar su efecto en el cliente valida que el juego interpretó la acción.

## Privacidad y límites operativos

Las imágenes permanecen en memoria y se descarta cada captura después de obtener sus píxeles reducidos. El APK carece de permiso de Internet. La sesión se detiene al salir del juego, bloquear la pantalla, perder la conexión con el servicio o superar diez minutos en primer plano. Las capturas no disponibles o los gestos rechazados pausan el seguimiento. Puede desactivarse el servicio desde Ajustes de Android.

El seguidor en vivo y el piloto del campo 3D son módulos distintos. Los pesos del simulador interpretan su propia paleta y su minimapa sintético. La versión 0.4 permite probar gestos y seguimiento visual sobre una referencia seleccionada; quedan pendientes reconocimiento general de personajes y mapas, gestión de inventario y juego autónomo de una partida completa. La integración está dirigida a la sesión de prueba que indicó el usuario. La prueba con un cliente simulado en Android no acredita compatibilidad con una versión concreta de Free Fire.

## Arquitectura

LiveSetup configura el cliente y las acciones. LiveService mantiene la sesión y el panel de parada, identifica la ventana activa, llama a AccessibilityService.takeScreenshot y dispatchGesture, y cierra los buffers de Android. Tracker selecciona y busca la referencia y actualiza la ganancia estimada. La prueba reproducible del seguidor está en tests/TrackerTest.java.
