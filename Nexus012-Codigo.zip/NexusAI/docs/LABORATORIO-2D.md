# NEXUS AI · Android 0.2.0

Laboratorio de aprendizaje por refuerzo en un simulador de navegación propio. La aplicación puede aprender desde cero en el teléfono, comparar su comportamiento y adoptar pesos nuevos sin reinstalar el APK. La sesión es local y funciona sin conexión. Esta primera entrega cubre el ciclo de entrenamiento y evaluación en una arena 2D.

La edición 0.2 lleva un icono adaptativo con el monograma N y puede instalarse junto a la 0.1. Tiene almacenamiento propio. Para trasladar pesos, usa Modelos → Exportar en la anterior e Importar candidato en esta edición.

## Instalar y empezar

1. Abre NEXUS-AI-0.2.apk en Android. Si Android solicita permiso para instalar desde el navegador o el gestor de archivos, concédelo a esa aplicación para la instalación. Puedes desactivarlo después.
2. Abre NEXUS AI y pulsa **Entrenar IA**. El círculo cian representa al agente. El anillo lavanda señala la salida. En el nivel de recolección, el rombo ámbar debe recogerse primero.
3. Cada 40 episodios el laboratorio evalúa el candidato. También puedes pulsar **Modelos → Evaluar candidato**. Un modelo aprobado aparece con un nuevo número de versión. **Ver agente** muestra la política activa sin explorar ni actualizar sus pesos.
4. Pulsa **Pausar** para guardar de inmediato. Al regresar, pulsa **Entrenar IA** para retomar. Los checkpoints periódicos limitan lo que puede perderse ante un cierre forzado.
5. **Iniciar demostración** habilita las flechas. Cada pulsación guarda el estado anterior y tu acción. Puedes eliminar el último ejemplo. El siguiente entrenamiento reutiliza las demostraciones.
6. **Ajustes** permite modificar recompensas, tasa de aprendizaje, descuento y carga de cómputo. Cambiar las recompensas inicia una memoria de refuerzo nueva para evitar mezclar escalas. Conserva los pesos aprendidos.
7. Para trasladar conocimientos, abre **Modelos → Exportar**, copia el texto y guárdalo. En la otra instalación, pega el texto, pulsa **Importar candidato** y evalúalo. El intercambio incluye solo pesos. Para usar el ejemplo preentrenado, copia el contenido de modelos/movilidad-120.json.

## Estructura del proyecto

| Ruta | Responsabilidad |
|---|---|
| app/src/main/AndroidManifest.xml | Punto de entrada, versión y compatibilidad Android. Sin permisos solicitados. |
| app/src/main/java/co/nexus/lab/NexusActivity.java | Actividad Java, WebView local, ciclo de vida y lecturas Android de batería, RAM y estado térmico. |
| app/src/main/assets/simulation.js | Generador de mapas con semilla, observación, movimientos, recompensas y búsqueda de ruta mínima. |
| app/src/main/assets/policy.js | Red neuronal compartida por las cuatro acciones, propagación hacia delante, gradientes y entrenamiento por demostración. |
| app/src/main/assets/trainer.js | Agente exploratorio, memoria de repetición, red objetivo, evaluación y promoción del candidato. |
| app/src/main/assets/storage.js | Dos checkpoints en almacenamiento local privado, checksum y recuperación del anterior. |
| app/src/main/assets/perception.js | Lectura de píxeles y clasificación de objetos según la paleta de la arena. |
| app/src/main/assets/index.html, style.css, ui.js | Arena, controles, telemetría, registro, importación y restauración. |
| modelos | Pesos iniciales reproducibles y ejemplo entrenado durante 120 episodios. |
| tests | Pruebas del núcleo y del flujo de la interfaz. |

## Cómo aprende

Una red de 121 parámetros estima el valor de cada movimiento. Cada acción comparte la misma red y recibe ocho características, entre ellas el progreso previsto hacia la meta, si hay un muro, si existe peligro y si se regresa a la posición anterior. Son observaciones estructuradas del simulador. El detector visual del panel de observación se evalúa por separado.

La política explora con probabilidad decreciente. Almacena hasta 256 transiciones y hasta 256 ejemplos humanos. En cada paso realiza cuatro actualizaciones estocásticas sobre muestras del búfer. Usa pérdida de Huber, selección de la acción siguiente mediante la red candidata y valoración mediante la red objetivo. Esta última se sincroniza cada 40 pasos. Los ejemplos humanos aportan una actualización supervisada adicional cada cuatro pasos cuando están disponibles.

Los episodios duran hasta 48 movimientos. Los tres niveles son movilidad, navegación con obstáculos y recolección con peligros. Se evalúan 24 semillas reservadas por nivel desbloqueado. Para activar un candidato necesita al menos 65 % de éxito en el nivel actual, superar al azar, mejorar respecto de la versión activa y mantener sus éxitos en niveles anteriores. Para avanzar de nivel requiere al menos 85 % de éxito y una promoción. La restauración recupera los pesos anteriores y el nivel correspondiente. El registro conserva las últimas 20 revisiones y un solo juego anterior de pesos activos.

Los resultados de evaluación usan siempre el mismo conjunto de validación para comparar versiones. Su reutilización introduce sesgo de selección. Los éxitos en la arena de movilidad no demuestran transferencia a otro juego.

## Compilar y probar

Abre la carpeta NexusAI en Android Studio con JDK 17, plataforma Android SDK 35 y acceso a las dependencias de Gradle durante la primera sincronización. El proyecto incluye el wrapper Gradle 8.9. En Linux o macOS ejecuta `./gradlew assembleDebug`. En Windows usa `gradlew.bat assembleDebug`. El resultado queda en app/build/outputs/apk/debug/app-debug.apk. Android mínimo 8.0 (API 26), objetivo Android 12 (API 31). La compilación entregada se ensambló con AAPT2, D8, zipalign y apksigner de Android SDK Build Tools 35.0.0 y tiene firma de desarrollo v2/v3. El ZIP contiene el código y no contiene credenciales de firma.

- Núcleo reproducible con Node.js: `node --test tests/core.test.js`.
- Interfaz con Python, Playwright y Chromium: `python tests/interface_test.py`. La variable CHROME_BIN permite elegir un ejecutable compatible.
- Para comprobar el paquete localmente: `apksigner verify --verbose NEXUS-AI-0.2.apk`.
- Reproducción de la medición inicial con semilla 4292 y 120 episodios, sin promoción intermedia: candidato 24/24, aleatorio 8/24, activo inicial 0/24, ruta mínima 24/24. El candidato y la ruta mínima promediaron 5,92 movimientos. Esta medición corresponde al núcleo en Node.js.

## Solución de problemas

- **El agente inicial repite movimientos.** Entrena al candidato. Ver agente reproduce la versión activa. Revisa la tabla antes de decidir si hace falta otra sesión.
- **Pausa al cambiar de aplicación.** Vuelve a la arena y pulsa Entrenar IA. También se pausa con memoria crítica, estado térmico Android 3 o superior, o batería por debajo del 15 % sin cargador.
- **No se puede guardar.** Libera espacio, exporta los pesos activos y conserva una copia. Borrar los datos de la aplicación o desinstalarla elimina los checkpoints.
- **Firma incompatible al instalar una compilación propia.** Exporta previamente los pesos. Android requiere la misma clave para reemplazar una aplicación instalada. Desinstalarla borra su memoria local.
- **Los modelos importados no se activan.** Comprueba el mensaje de integridad y la tabla de evaluación. La importación sustituye el candidato. La activación depende del rendimiento medido.

## Alcance y trabajo pendiente

La versión 0.2 implementa el simulador propio, el entrenamiento neuronal, las demostraciones, la comparación y la recuperación de modelos. La visión reconoce la paleta del simulador. La aplicación no se conecta a Free Fire. La integración externa depende de una interfaz autorizada. Quedan pendientes el análisis de grabaciones, escenarios con adversarios y zona segura dinámica, el currículo completo de diez etapas, entrenamiento programado en segundo plano y actualización remota firmada de contenido. La suma de comprobación de los pesos detecta daños accidentales y no acredita la identidad de su autor. La latencia, el consumo y la estabilidad térmica en el Samsung Galaxy A21s físico requieren medición en ese dispositivo.

### Recuperación cuando se cierra Android System WebView

Si Android cierra el proceso de renderizado durante el uso del laboratorio, la actividad abre una arena nativa de movilidad. Tiene controles Entrenar IA y Pausar, un estimador neuronal compacto de cuatro pesos y almacenamiento independiente en SharedPreferences. Conserva sus pesos y conteos al cerrar la app. El laboratorio completo se vuelve a intentar al abrir la actividad de nuevo. Para diagnóstico se puede iniciar directamente con `adb shell am start -n co.nexus.lab.design/co.nexus.lab.NexusActivity --ez lightweight true`.
