# NEXUS 0.5 · Partida por demostraciones

Instala el APK sobre NEXUS 0.4. Abre Prueba de controles en Free Fire y habilita el servicio de accesibilidad como en la versión anterior. Esta edición conserva el seguimiento de una diana y agrega dos modos que comparten un perfil por edición del juego.

1. Elige Enseñar una partida y abre el juego. Con el teléfono horizontal, pulsa el nombre de la fase en el panel para cambiar entre Lobby, Despliegue, Partida y Resultados.
2. Antes de una acción representativa, pulsa Mostrar gesto. Cuando aparezca Cancelar ejemplo, toca o arrastra sobre el lugar que usarías normalmente. El servicio entrega el gesto al juego y guarda un ejemplo cuando Android confirma la entrega. Repite para iniciar, desplegarte y responder a diversas escenas. Evita enseñar gestos en tiendas, mensajes y pantallas ajenas a la partida.
3. En la pantalla final elige Resultados y pulsa Mostrar gesto. Aquí se guarda solo la referencia visual. Pulsa Detener. Cada fase necesita al menos un ejemplo para habilitar el ensayo; la cobertura de escenas reales normalmente exige muchos más.
4. Selecciona Ejecutar una partida aprendida. Abre el juego en el lobby y pulsa Iniciar. El servicio compara la pantalla con tus ejemplos, reproduce el gesto asociado y vuelve a observar antes de decidir. Detectar Resultados finaliza la sesión. La ventana temporal es de 45 minutos desde que el juego aparece en primer plano.
5. Las escenas desconocidas generan espera. La falta prolongada de coincidencias o la repetición de una acción pausa la sesión. Detener finaliza inmediatamente el bucle. La salida del juego, el bloqueo de pantalla o un cambio de orientación durante la ejecución interrumpen la sesión.

## Qué aprende

El perfil guarda hasta 160 ejemplos por edición. Cada ejemplo contiene una descripción cromática reducida de 16 × 9 regiones, una etiqueta de fase y un gesto individual normalizado con su duración. Los datos quedan en el almacenamiento privado de NEXUS. No se almacenan imágenes completas. Se priorizan la fase presente y su sucesora y se permite pasar de despliegue a resultados en una eliminación temprana. El umbral de similitud limita cuándo se ejecuta una acción.

La prueba MatchBookTest comprueba recuperación de un perfil, secuencia de cuatro fases, rechazo de escenas desconocidas y rechazo de una coincidencia ambigua entre fases con escenas sintéticas. La versión 0.5 no incluye demostraciones tomadas de Free Fire ni tiene validación de una partida real completa. Cambios de iluminación, mapas, HUD, animaciones o decisiones que requieran acciones simultáneas pueden impedir que finalice. El reconocimiento por similitud no equivale a comprensión táctica.
