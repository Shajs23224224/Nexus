import co.nexus.lab.field.*;
import java.io.*;
import java.util.*;

public final class FieldBenchmark {
    static final int RUNS=32;
    static int[] evaluate(Pilot p, boolean random){
        int[] wins=new int[4];
        for(int m=0;m<4;m++)for(int i=0;i<RUNS;i++){
            Practice episode=new Practice(m,900000L+i*7919L+m*121);
            Random rng=new Random(7933+i);
            while(!episode.field.done){
                int[] cmd=random?new int[]{rng.nextInt(3),rng.nextInt(3),rng.nextInt(2),rng.nextInt(2)}:null;
                episode.tick(p,false,cmd);
            }
            if(episode.field.won)wins[m]++;
        }
        return wins;
    }
    public static void main(String[] args)throws Exception{
        Pilot p=new Pilot(41);
        System.out.println("Inicial "+Arrays.toString(evaluate(p,false)));
        System.out.println("Azar "+Arrays.toString(evaluate(p,true)));
        for(int i=0;i<640;i++){
            Practice episode=new Practice(i%4,i*2399L+41);
            while(!episode.field.done)episode.tick(p,true,null);
        }
        int[] learned=evaluate(p,false);
        System.out.println("Entrenada "+Arrays.toString(learned)+" / "+RUNS+" · actualizaciones "+p.updates);
        if(args.length>0)try(DataOutputStream out=new DataOutputStream(new FileOutputStream(args[0]))){p.write(out);}
        ByteArrayOutputStream bytes=new ByteArrayOutputStream();p.write(new DataOutputStream(bytes));
        Pilot restored=Pilot.read(new DataInputStream(new ByteArrayInputStream(bytes.toByteArray())));
        if(!Arrays.equals(evaluate(restored,false),learned))throw new AssertionError("Persistencia");
        for(int n:learned)if(n==0)throw new AssertionError("Misión sin éxitos");
    }
}
