import co.nexus.lab.field.*;
import java.io.*;
import java.util.*;

/** Independent final trial on a disjoint seed range. Does not update the loaded model. */
public final class FieldHoldout {
    public static void main(String[] args)throws Exception{
        Pilot policy;
        try(DataInputStream in=new DataInputStream(new FileInputStream(args[0]))){policy=Pilot.read(in);}
        long updates=policy.updates;
        for(int mission=0;mission<4;mission++){
            int[] wins=new int[2];int steps=0,hits=0,shots=0;
            for(int run=0;run<128;run++)for(int random=0;random<2;random++){
                long seed=0x1e320874L+run*5309L+mission*5915587L;
                Practice p=new Practice(mission,seed);Random rng=new Random(seed^3193L);
                while(!p.field.done){
                    int[] cmd=random==1?new int[]{rng.nextInt(3),rng.nextInt(3),rng.nextInt(2),rng.nextInt(2)}:null;
                    p.tick(policy,false,cmd);
                }
                if(p.field.won)wins[random]++;
                if(random==0){steps+=p.field.ticks;hits+=p.field.hits;shots+=p.field.shots;}
            }
            System.out.println(Field.NAMES[mission]+": modelo "+wins[0]+"/128; azar "+wins[1]+"/128; pasos medios "+steps/128.0+"; impactos "+hits+"/"+shots);
        }
        if(policy.updates!=updates)throw new AssertionError("Pesos alterados en evaluación");
    }
}
