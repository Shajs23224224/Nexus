package co.nexus.lab.live;
import java.io.*;
import java.util.*;
public final class MatchBookTest{
    static byte[] scene(int n){
        int[] rgb=new int[224*112];Random r=new Random(151+n);
        for(int y=0;y<112;y++)for(int x=0;x<224;x++){
            int c=(n*66+x/32*8+r.nextInt(8))&255;rgb[y*224+x]=c*0x010101;
        }return MatchBook.describe(rgb,224,112);
    }
    public static void main(String[] args)throws Exception{
        MatchBook b=new MatchBook();
        for(int i=0;i<4;i++)b.add(i,scene(i),.3f,.4f,.6f,.2f,150);
        if(!b.ready())throw new AssertionError();
        ByteArrayOutputStream bytes=new ByteArrayOutputStream();b.write(new DataOutputStream(bytes));
        b=MatchBook.read(new DataInputStream(new ByteArrayInputStream(bytes.toByteArray())));
        int phase=0;
        for(int i=0;i<4;i++){
            if(b.choose(phase,scene(i))!=null)throw new AssertionError("Un solo frame");
            if(i==3)b.choose(phase,scene(i));
            MatchBook.Example e=b.choose(phase,scene(i));if(e==null||e.phase!=i)throw new AssertionError("fase "+i);phase=e.phase;
        }
        if(b.choose(0,scene(2))!=null)throw new AssertionError("salto indebido");
        b.add(1,scene(0),.1f,.2f,.1f,.2f,80);
        if(b.choose(0,scene(0))!=null)throw new AssertionError("ambiguo");
        System.out.println("Perfil recuperado; cuatro fases, pantalla desconocida y ambigüedad: OK");
    }
}
