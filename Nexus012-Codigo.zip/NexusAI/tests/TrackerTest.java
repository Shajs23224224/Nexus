import co.nexus.lab.live.Tracker;
import java.util.Arrays;
public final class TrackerTest {
    private static int[] patch(int x,int y){
        int[] img=new int[Tracker.W*Tracker.H];Arrays.fill(img,0xff122139);
        for(int dy=-8;dy<=8;dy++)for(int dx=-8;dx<=8;dx++){
            int v=(dx*dx+dy*dy*11+dx*dy+113)&255;
            img[(y+dy)*Tracker.W+x+dx]=0xff000000|((v*3&255)<<16)|(v<<8)|(v*7&255);
        }
        return img;
    }
    public static void main(String[] args){
        Tracker t=new Tracker();
        if(!t.select(patch(140,76),140,76))throw new AssertionError("Seleccionar");
        int[] pos=t.locate(patch(132,70));
        if(pos==null||pos[0]!=132||pos[1]!=70)throw new AssertionError("Movimiento");
        if(t.locate(new int[Tracker.W*Tracker.H])!=null)throw new AssertionError("Pérdida");
        if(t.select(new int[Tracker.W*Tracker.H],130,55))throw new AssertionError("Textura");
        if(Tracker.adapt(1,.2,.14,.03)<=1)throw new AssertionError("Sensibilidad");
        System.out.println("Selección, seguimiento, pérdida de imagen y ajuste de ganancia: OK");
    }
}
