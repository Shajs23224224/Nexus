package co.nexus.check;
import android.app.*;
import android.content.*;
import android.os.*;
import android.view.*;
import android.widget.*;

public final class FieldCheck extends Instrumentation {
    private Bundle args;
    private Activity activity;
    public void onCreate(Bundle b){super.onCreate(b);args=b;start();}
    private TextView find(View view,String s,boolean prefix){
        if(view instanceof TextView){
            String text=((TextView)view).getText().toString();
            if(prefix?text.startsWith(s):text.equals(s))return (TextView)view;
        }
        if(view instanceof ViewGroup){
            ViewGroup group=(ViewGroup)view;
            for(int i=0;i<group.getChildCount();i++){TextView found=find(group.getChildAt(i),s,prefix);if(found!=null)return found;}
        }
        return null;
    }
    private String value(String key){
        final String[] answer={""};runOnMainSync(()->{
            TextView v=find(activity.getWindow().getDecorView(),key,true);
            if(v!=null)answer[0]=v.getText().toString();
        });return answer[0];
    }
    private void click(String label){
        boolean[] ok={false};runOnMainSync(()->{
            TextView view=find(activity.getWindow().getDecorView(),label,false);
            if(view!=null)ok[0]=view.performClick();
        });
        if(!ok[0])throw new AssertionError(label);
    }
    private void waitFor(String prefix,String text){
        long deadline=SystemClock.elapsedRealtime()+60000;
        do{if(value(prefix).contains(text))return;SystemClock.sleep(400);}while(SystemClock.elapsedRealtime()<deadline);
        throw new AssertionError(text+" · "+value(prefix));
    }
    private long updates(){return Long.parseLong(value("Prácticas locales").split("Actualizaciones del modelo ")[1].split("\n")[0]);}
    private View clip(View v){
        if(v.getClass().getName().endsWith("$ClipView"))return v;
        if(v instanceof ViewGroup){ViewGroup g=(ViewGroup)v;for(int i=0;i<g.getChildCount();i++){
            View f=clip(g.getChildAt(i));if(f!=null)return f;}}
        return null;
    }
    private void review()throws Exception{
        Activity field=activity;
        activity=startActivitySync(new Intent().setClassName("co.nexus.lab.design","co.nexus.lab.ReviewActivity").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
        java.io.File f=new java.io.File(activity.getCacheDir(),"trial.mp4");
        try(java.io.InputStream in=getContext().getAssets().open("sample.mp4");java.io.FileOutputStream out=new java.io.FileOutputStream(f)){
            byte[] b=new byte[4096];int n;while((n=in.read(b))>=0)out.write(b,0,n);
        }
        runOnMainSync(()->callActivityOnActivityResultForTest(new Intent().setData(android.net.Uri.fromFile(f))));
        waitFor("0.0 /","ejemplos");
        runOnMainSync(()->{
            View v=clip(activity.getWindow().getDecorView());long now=SystemClock.uptimeMillis();
            MotionEvent e=MotionEvent.obtain(now,now,MotionEvent.ACTION_UP,v.getWidth()/2f,v.getHeight()/2f,0);
            v.dispatchTouchEvent(e);e.recycle();
        });
        waitFor("0.0 /","etiquetada");click("+0,5 s");waitFor("0.5 /","ejemplos");
        runOnMainSync(()->activity.finish());activity=field;
    }
    private void callActivityOnActivityResultForTest(Intent data){
        try{
            java.lang.reflect.Method m=activity.getClass().getDeclaredMethod("onActivityResult",int.class,int.class,Intent.class);
            m.setAccessible(true);m.invoke(activity,1,Activity.RESULT_OK,data);
        }catch(Exception e){throw new AssertionError(e);}
    }
    @Override public void onStart(){
        Bundle report=new Bundle();
        try{
            Intent launch=new Intent().setClassName("co.nexus.lab.design","co.nexus.lab.FieldActivity").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            activity=startActivitySync(launch);
            if("true".equals(args.getString("fixture"))){
                Instrumentation.ActivityMonitor monitor=addMonitor("co.nexus.fixture.Game",null,false);
                // A cross-process launch is recorded by the instrumentation before Android starts the fixture.
                click("Abrir Free Fire");SystemClock.sleep(1800);
                if(!activity.isFinishing()&&value("Prácticas locales").contains("no encontró"))throw new AssertionError("Paquete invisible");
                report.putString("launcher","Llamada al paquete de prueba; comprueba la actividad superior con dumpsys.");
                removeMonitor(monitor);
            }else{
                long before=updates();click("Entrenar");
                long until=SystemClock.elapsedRealtime()+45000;
                while(updates()<=before&&SystemClock.elapsedRealtime()<until)SystemClock.sleep(400);
                click("Pausar");if(updates()<=before)throw new AssertionError("Pesos sin actualizar");
                click("Recuperar modelo");if(updates()!=before)throw new AssertionError("Restauración");
                click("Evaluar IA");waitFor("Prácticas locales","/16 objetivos");
                report.putString("evaluation",value("Prácticas locales"));click("Abrir Free Fire");
                waitFor("Prácticas locales","no encontró");report.putString("launchMissing","OK");review();report.putString("review","MP4, anotación y avance: OK");
            }
            report.putString("result","PASS");finish(Activity.RESULT_OK,report);
        }catch(Throwable t){report.putString("failure",android.util.Log.getStackTraceString(t));finish(Activity.RESULT_CANCELED,report);}
    }
}
