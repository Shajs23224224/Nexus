'use strict';
const assert=require('node:assert/strict'),test=require('node:test');
const Sim=require('../app/src/main/assets/simulation.js');
const Policy=require('../app/src/main/assets/policy.js');
const Lab=require('../app/src/main/assets/trainer.js');
test('Los mapas de tres niveles tienen una ruta segura y repetible',()=>{
  for(let level=0;level<3;level++)for(let seed=0;seed<100;seed++){
    const e=Sim.create(seed,level);assert.deepEqual(e,Sim.create(seed,level));
    while(!e.done) Sim.step(e,Sim.heuristic(e));assert.ok(e.won);
  }
});
test('El candidato aprende, persiste y supera la política aleatoria',()=>{
  const m=Lab.fresh(),w=m.active.slice();
  while(m.episodes<120)Lab.cycle(m);
  assert.deepEqual(w,m.active);assert.notDeepEqual(m.candidate,w);assert.ok(Policy.valid(m.candidate));
  assert.equal(m.replay.length,256);
  const recovered=JSON.parse(JSON.stringify(m)),table=Lab.evaluate(recovered);
  assert.deepEqual(table,Lab.evaluate(m));const r=table[0];assert.ok(r.candidate.wins>r.random.wins);
  assert.ok(Lab.promote(recovered,table));assert.deepEqual(recovered.previous.weights,w);
  assert.deepEqual(recovered.active,recovered.candidate);console.log(JSON.stringify(r));
});
test('Reanudar un checkpoint conserva la trayectoria y el entrenamiento',()=>{
  const m=Lab.fresh();for(let i=0;i<25;i++)Lab.cycle(m);const saved=JSON.parse(JSON.stringify(m));
  for(let i=0;i<70;i++){Lab.cycle(m);Lab.cycle(saved);}
  assert.deepEqual(saved.candidate,m.candidate);assert.deepEqual(m.session,saved.session);
});
test('Una demostración incrementa la preferencia por la acción etiquetada',()=>{
  const e=Sim.create(741,0),state=Sim.observe(e),a=Sim.heuristic(e),w=Lab.fresh().candidate;
  const margin=()=>Policy.forward(w,state[a])-Math.min(...state.map(s=>Policy.forward(w,s)));
  const before=margin();for(let i=0;i<100;i++)Policy.imitate(w,state,a,.01);
  assert.ok(margin()>before);
});
