"""Prueba de integración en Chromium. Requiere playwright y un binario chromium."""
import shutil
import os
from pathlib import Path
from playwright.sync_api import sync_playwright

with sync_playwright() as api:
    browser = api.chromium.launch(executable_path=os.environ.get('CHROME_BIN') or shutil.which('chromium'), args=['--no-sandbox'])
    page = browser.new_page(viewport={'width': 360, 'height': 740})
    errors = []
    page.on('pageerror', lambda error: errors.append(str(error)))
    page.goto((Path(__file__).resolve().parents[1] / 'app/src/main/assets/index.html').as_uri())
    page.click('#train')
    page.wait_for_function('m.episodes >= 4')
    page.click('#stop')
    episodes = page.inner_text('#episodes')
    page.reload()
    assert page.inner_text('#episodes') == episodes
    page.click('summary')
    page.click('#scan')
    assert 'agente 1' in page.inner_text('#vision')
    page.click('#teach')
    page.click('[data-a="1"]')
    assert page.evaluate('m.demos.length') == 1
    page.click('#stop')
    page.click('[data-tab="models"]')
    page.click('#evaluate')
    assert 'Aleatoria' in page.inner_text('#results')
    page.click('#export')
    data = page.input_value('#exchange')
    assert 'nexus-q1' in data
    page.fill('#exchange','{}')
    page.click('#import')
    assert 'incompatible' in page.inner_text('#modelmsg')
    page.fill('#exchange',data)
    page.click('#import')
    assert 'importado' in page.inner_text('#modelmsg')
    page.click('[data-tab="settings"]')
    page.fill('#rate','.012')
    page.click('#apply')
    assert page.evaluate('m.rate') == .012
    page.reload()
    assert page.evaluate('m.rate') == .012
    assert page.evaluate('document.documentElement.scrollWidth <= innerWidth')
    # Verifica aprobación, restauración y bloqueo térmico.
    page.evaluate('Object.assign(m,Lab.fresh());while(m.episodes<120)Lab.cycle(m)')
    page.click('[data-tab="models"]')
    page.click('#evaluate')
    assert page.evaluate('m.previous !== null')
    page.click('#rollback')
    assert page.evaluate('m.previous === null && m.history.at(-1).restored === 1')
    page.click('[data-tab="arena"]')
    page.evaluate('window.Device={read:()=>JSON.stringify({thermal:3,foreground:true})}')
    page.click('#train')
    assert 'En pausa' in page.inner_text('#status')
    # Corrompe únicamente la ranura activa, después de guardar dos checkpoints.
    page.evaluate("""() => {
        Vault.save(m); Vault.save(m);
        localStorage.setItem('nexus.lab.v1.'+localStorage.getItem('nexus.lab.v1.head'), 'incompleto');
        window.suspendLab=()=>{};
    }""")
    page.reload()
    assert 'recuperó' in page.inner_text('#message')
    assert page.evaluate('m.episodes >= 120')
    assert not errors, errors
    browser.close()
    print('Interfaz, persistencia, enseñanza, visión, evaluación, intercambio y ajustes: OK')
